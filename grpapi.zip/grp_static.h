/*

  ShadowFlare GRP Static Library. (c) ShadowFlare Software 2002

*/

#ifndef GRPLIB_INCLUDED
#define GRPLIB_INCLUDED

#ifndef GRPAPI_STATIC
#define GRPAPI_STATIC
#endif

#include "grpapi.h"

#endif

