########################################################
########################################################
##         ____       ____  ______  _______ ____      ##
##  __  __/ __ )___  / __ \/ ____ \/_  __(_) __ \____ ##
## / / / / __  / _ \/ /_/ / / __ `/ / / / / / / / __ \##
##/ /_/ / /_/ /  __/ _, _/ / /_/ / / / / / /_/ / / / /##
##\__,_/_____/\___/_/ |_|\ \__,_/ /_/ /_/\____/_/ /_/ ##
######################### \____/########################
########################################################
__________________
Installation Notes
������������������
-Extract all files in the zip into one folder on your hard drive.

-Execute uBeR@TiOn.exe

NOTE: Visual Basic 6 Runtime Files and MpqControl are required.

____________________
How to use uBeR@TiOn
��������������������
Click 'Open' and select the map you would like to open.

The Strings Manager can be used view all the strings used in the map,
to recycle strings so that the section may be compacted, or to delete
unused strings to save wasted space.
It can also be used to edit strings by double-clicking on a string.
'Jump to:' is used for jumping to a specific string. You will need to
enter the number of the string.
'Filter text:' is used for filtering text and searching for a specific
string or part of a string.

The Compress function is to make your map file smaller to save space.
To get info about what each combo compression does, click on the '?'

The CWUP Slots Editor is a tool used to edit the Properties Slots used
for triggers. 

The Player Colors Editor is for Brood War maps only and is used to change
the colors of players in the game.

The IEP Manager is a tool used to import and export sections of the map.
To export sections, check the sections you want to export and then press
the button labelled 'Export'.
To import sections, press 'Open file', select a file to import from, check
the sections you want to import, then press 'Import Selected' and press
'Close file' when you are done.

The uBeR@Te function is for protecting the map file. It automatically
compresses the file before protection.

Press the 'Save As' button to save the map or else all unsaved data shall
be lost.

___
FAQ
���
Q: There is a glitch! What do I do!?
A: First make sure you are using the latest version (CTRL + N for autoupdate)
   Then Report it to LegacyWeapon@gmail.com

Q: Why should I use uBeR@TiOn?
A: Better protection = smaller chance of map theft.

Q: I want to talk to the creator of this program!
A: That's not a question but if you read a bit more you'll see how.

_______
Contact
�������
Email: LegacyWeapon@gmail.com

LegacyWeapon@USEast

_________
Changelog
���������
v2.0.0.9
Some minor protection issues fixed
Minor Compression bugs fixed

v2.0.0.8b
Fixed map inflation

v2.0.0.8
Rewrote all strings coding
EUD updated
EAS added
Protection level increased

v2.0.0.7
Fixed misc bugs (mostly with UberEdit)

v2.0.0.6
Created UberEdit (Trigger Manager with extended trigger support)

v2.0.0.5
Sorry for the fast updates!
Strings section parsing fixed

v2.0.0.4
Strings section parsing fixed
Null strings fix updated

v2.0.0.3
Null string bugs fixed
Updated protection

v2.0.0.2
Strings Section fixed.
Added backup for protection overwrite.
Added autoupdate checker (every 20 days asks)
Added 'Please Wait...' form.
Changed strings parser style.
Updated protection

v2.0.0.1
File compression updated
Removing 'never' triggers optimized.

v2.0.0.0
Standalone protection
Strings manager
Compression
Player colors
IEP Manager
CUWP Slot Editor

v1.1.0.0
Updating loading sequence and saving sequence.
Changed About page.
Added greater protection against PROEdit opening.
Update icon (in every form and looks better).
Updated automatic updater (much better looking and works better).

v1.0.0.5
Fixed Audio Compression Display Text (Low and High switched)
Added automatic updater.

v1.0.0.4
Added section jumping for faster uBeR@TiOn.
Fixed compression.

v1.0.0.3
Fixed config file and protection updated.

v1.0.0.2
Fixed crashing error and save/open glitch. Much thanks to DTBK!

v1.0.0.1
Added about page with special thanks and beta testers.

v1.0.0.0
Just finished making program. Sent out to Beta Testers. No form for about page yet.