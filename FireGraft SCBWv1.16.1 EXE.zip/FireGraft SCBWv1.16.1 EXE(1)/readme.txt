README!

So, this is a quick update to FG that is not intended for anything except to get you guys some stuff.

It has limited 1.16.1 support and features some bug fixes.

1.16.1 has no exe edits.  Live with it.

I'm possibly going to make support in the new version to open FGP's saved from here, but i make no promises.  I've changed enough sizes and such that it might drive me crazy to try to do.

I did fix some bugs here and there.  You can tell me about some of the existing ones, but most of the time I'll just tell you they're fixed in the new version.

No timetable for that new version yet.  It's on and off work.

Enjoy.