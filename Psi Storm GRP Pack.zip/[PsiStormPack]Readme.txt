Thank you for downloading Psi Storm Pack, by Voyager7456[MM]!

This pack is a collection of .grp (StarCraft graphics files). They will not run by themselves as a mod. If you are looking for different colored Psi Storms that will run as a stand-alone mod, please check out my Psi Storm SEMPQ Pack, most likely located on the site you downloaded this mod from.

INSTRUCTIONS:
Rename the color that you want to psistorm.grp.
Make a new MPQ Archive.
Add the psistorm.grp file to this path: unit\thingy\psistorm.grp
Enjoy!

Please support the production of more great mods, visit these links:

http://s9.invisionfree.com/blizznet/index.php?act=idx - Clan [MM] Forums
www.staredit.net - Staredit Network