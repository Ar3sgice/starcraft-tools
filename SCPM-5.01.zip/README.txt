******************************************
* Starcraft Picture Mapper 5 Readme File *
******************************************

***
FAQ
***

Q: SCPM5 doesn't work for me!
A: Fist of all, SCPM5 requires the .NET Framework 2 from Microsoft.  In layman's terms, this is a driver/dll package required to run applications build with the .NET Framework 2.  You can get it (directly from Microsoft) from here: http://www.microsoft.com/downloads/details.aspx?familyid=0856eacb-4362-4b0d-8edd-aab15c5e04f5&displaylang=en  I have programmed and tested SCPM5 on the Windows XP operating system (Service Pack 2 installed).  If you are attempting to run it on another OS or on a Windows XP emulator or virtual machine, be advised that the program may not work!  If you still encounter problems, take a screenshot of the error message, and email me at starcraftpicturemapper@gmail.com the picture along with any and all relevant details, and I will do my best to fix it and help you out.

Q: How many different shades does this program use for each tile set?
A: The number of shades available for each tile set is listed below.  At first you may think that these numbers are inaccurate, but remember: most maps have many similar shades and all of them lack diversity.  So for example, while there may be 50 different shades of blue in the Twilight tile set, there is not a single shade of yellow.

	Twilight        74
	Space Platform  79
	Jungle World    73
	Installation    56
	Ice             72
	Desert          80
	Ashworld        71
	Badlands        91

Q: Will there be an SCPM6?
A: As of right now I have no plans to create a SCPM6, and I fully intend SCPM5 to be the final version.  However, I am known to randomly change my mind about nearly everything, so you never know!  If a cool new feature comes to mind or I am able to identify and fix a big bug, I may make a new version, or at least a new release, perhaps 5.1.

Q: How can I contact you?
A: You can reach me using the following methods:
AOL Instant Messenger (AIM): FernandoH26
Email: starcraftpicturemapper@gmail.com
Website: http://www.clanscag.com (Click on "Contact Scag" on the left hand side, it sends me an email)

Q: Did you make the "sexy pics" maps?
A: I made all the sexy pics maps from sexy pics 11 - sexy pics 110 to promote SCPM2 and SCPM3.  Sexy pics 1 - 10 were made by Vangaurd.  You can download ALL the sexy pic maps at http://www.clanscag.com

Q: How does your program make valid .SCM and .SCX maps?
A: First of all, you can think of StarCraft maps as zip files, but with extensions of .SCM and .SCX instead of .ZIP.  Instead of ZIP, they are known as MPQ archives.  SCPM5 uses an API library named lmpqapi.dll written by Andrey Lelikov.  This library allows it to write valid SC maps!  The actual map data itself is first created by SCPM as an uncompressed scenario file, and then it is compressed into a valid Starcraft map.

In order to create the uncompressed scenario file, I had to do a bit of research and reverse engineering of the Starcraft map file structure.  Because of this, I have fairly thorough knowledge of map files and their internal structure.  If you are a map maker or tinkerer and are interested in this information, please take a look at the source code to see my research.

***
About SCPM5
***

SCPM5 is the fourth incarnation of a program I wrote several years ago.

The first version was meant for private use by me and me alone, and honestly was not fit for public distribution.  I thought some people would like to fiddle with it, so I created SCPM2 using Visual Basic 6.  It allowed users to choose from a limited array of tile sets, and the images were all basically in shades of gray/blue/green depending on the tile set.

Several months later, I learned a few things about the MFC classes in school, and decided to make SCPM3 using Visual C++ 6.  This version featured every tile set, and included all colors available for each tile set.  After completing SCPM3 I was honestly never planning to return to create any more versions.

Several people would contact me periodically inquiring about a new version, but I was too busy with school/work to be able to make a new one.  Fast forward to March 2006, when I had learned the basics of Visual Studio .NET 2003 and was eager to try out my skills.  At this point I decided to revisit SCPM, and make another version, SCPM4, thanks to Relentless[3R], which contacted me asking for 256x256 maps.  In SCPMv4, the user can choose the size of the output map, and several compatibility problems with StarForge were resolved.

Fast forward a couple of years, and after learning C# and a few things about the .NET framework 2, I decided to once again upgrade SCPM, this time to version 5.  This one uses lmpqapi.dll directly (without many of the dirty tricks of the previous ones) and best of all, its open source!  It is released under the GNU GPL, and the source is available at http://www.clanscag.com  Improvements include optional map revealers/start locations, large image preview, imrpoved map compatability due to more reverse engineering, and a few other nice little options.

***
License & Legal
***

Copyright � 2008 Fernando Hernandez

SCPM5 is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SCPM5 is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SCPM5.  If not, see <http://www.gnu.org/licenses/>.

StarCraft and StarCraft Brood War are owned/copyrighted/trademarked by Blizzard entertainment.
All trademarked/copyrighted items, logos, images, etc referenced herein are the properties of their respective owners.