Starforge Plus - Readme

Features:

  -More organized sound, units, upgrades, techs, and sprite files.
 
  -Less files that you do not need.

  -Does not need to be installed you just run it from this file.

  -Removed "Crashes Starcraft", and Unused from sprites.

  -All sounds work.

Installation

  -Extract this file to a spot on your computer where you will run
it from then create a shortcut of Starforge.exe and place it on
your program list.

Extra:

I also have Heimdal's permission to send this to people
or post on sites here is my proof.

"My Aim Name: look at that, and read the readme I wana know if I can put that
onsites.
StarForgeFB: sure"

So dont worry its legal!