Firegraft Version 0.91

Supported Starcraft versions
1.14 without exe edits.
1.15 with full exe edits.

This version of Firegraft is the first public release.  
The files from the previous version(s) which were tested 
by people are not meant to work with this version.  The FGP 
file underwent some significant changes, and I don't feel 
like finding a way to update them.

A couple of things that might not be so obvious(this list
is likely to grow from version to version)...

	*Clicking on a button in the preview jumps to it.

	*Double-clicking on a blank spot creates a blank 
	 button there.

	*Presets for non-units don't get icons or strings
	 preset.  I might in the distant future make a
	 file format which they can be read from to work 
	 right, but not now.

	*The -> button on the button sets tab will jump to 
	 the Dat Req of the variable next to it, if it 
	 exists.  It does know the if you should be using
	 the Tech Research or Tech Use field for the
	 selected function.

	*While I spent several hours trying to verify all 
	 the exe edits, there are over 230 of them, and I
	 cannot promise I typed everything right.  Same 
	 goes for spelling.

	*Icons are 32x32, 256 color, until someone shows
	 me code to get it right for all sizes of icons.

	*The tmp files saved out by the autosave feature are 
	 .fgp files that can be placed in an mpq with the
	 proper path.  I'm working on a stable way to open
	 just them alone.

	*The MPQ path of any Firegraft plugins should be 
	listed in Plugins\pluginlist.txt.

Any bugs and/or suggestions can be either PM'd to me or 
posted on Maplantis or Warboards, or can be emailed directly
to me at renegade_2395@yahoo.com.

DiscipleOfAdun.