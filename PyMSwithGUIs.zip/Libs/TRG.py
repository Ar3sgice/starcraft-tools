from utils import *
import TBL, AIBIN

import struct, re, os

player_ids = [
	'Player 1',
	'Player 2',
	'Player 3',
	'Player 4',
	'Player 5',
	'Player 6',
	'Player 7',
	'Player 8',
	'Player 9',
	'Player 10',
	'Player 11',
	'Player 12',
	'Player 13',
	'Current Player',
	'Foes',
	'Allies',
	'Neutral Players',
	'All Players',
	'Force 1',
	'Force 2',
	'Force 3',
	'Force 4',
	'Unused 1',
	'Unused 2',
	'Unused 3',
	'Unused 4',
	'Non Allied Victory Players'
]

resource_types = [
	'Ore',
	'Gas',
	'Ore and Gas'
]

unit_types = [
	'None',
	'Any Unit',
	'Men',
	'Buildings',
	'Factories'
]

score_types = [
	'Total',
	'Units',
	'Buildings',
	'Units and Buildings',
	'Kills',
	'Razings',
	'Kills and Razings',
	'Custom',
]

unit_orders = [
	'Move',
	'Patroll',
	'Attack'
]

ally_status = [
	'Enemy',
	'Ally',
	'Allied Victory'
]

unit_properties = [
	'Cloaked',
	'Burrowed',
	'In Transit',
	'Hallucinated',
	'Invincible',
	'Unknown1',
	'Unknown2',
	'Unknown3',
	'Unknown4',
	'Unknown5',
	'Unknown6',
	'Unknown7',
	'Unknown8',
	'Unknown9',
	'Unknown10',
	'Unknown11'
]

unit_data = [
	'Owner',
	'Health',
	'Shields',
	'Energy',
	'Resources',
	'AmountInHanger',
	'Unknown'
]

class TRG:
	conditions = [
		'NoCondition',
		'CountdownTimer',
		'Command',
		'Bring',
		'Accumulate',
		'Kill',
		'CommandTheMost',
		'CommandsTheMostAt',
		'MostKills',
		'HighestScore',
		'MostResources',
		'Switch',
		'ElapsedTime',
		None, #Used to signify Mission Briefing. Unused in .TRG files.
		'Opponents',
		'Deaths',
		'CommandTheLeast',
		'CommandTheLeastAt',
		'LeastKills',
		'LowestScore',
		'LeastResources',
		'Score',
		'Always',
		'Never'
	]
	actions = [
		'NoAction',
		'Victory',
		'Defeat',
		'PreserveTrigger',
		'Wait',
		'PauseGame',
		'UnpauseGame',
		'Transmission',
		'PlayWAV',
		'DisplayTextMessage',
		'CenterView',
		'CreateUnitWithProperties',
		'SetMissionObjectives',
		'SetSwitch',
		'SetCountdownTimer',
		'RunAIScript',
		'RunAIScriptAtLocation',
		'LeaderBoardControl',
		'LeaderBoardControlAtLocation',
		'LeaderBoardResources',
		'LeaderBoardKills',
		'LeaderBoardPoints',
		'KillUnit',
		'KillUnitAtLocation',
		'RemoveUnit',
		'RemoveUnitAtLocation',
		'SetResources',
		'SetScore',
		'MinimapPing',
		'TalkingPortrait',
		'MuteUnitSpeech',
		'UnmuteUnitSpeech',
		'LeaderboardComputerPlayers',
		'LeaderboardGoalControl',
		'LeaderboardGoalControlAtLocation',
		'LeaderboardGoalResources',
		'LeaderboardGoalKills',
		'LeaderboardGoalPoints',
		'MoveLocation',
		'MoveUnit',
		'LeaderboardGreed',
		'SetNextScenario',
		'SetDoodadState',
		'SetInvincibility',
		'CreateUnit',
		'SetDeaths',
		'Order',
		'Comment',
		'GiveUnitstoPlayer',
		'ModifyUnitHitPoints',
		'ModifyUnitEnergy',
		'ModifyUnitShieldPoints',
		'ModifyUnitResourceAmount',
		'ModifyUnitHangerCount',
		'PauseTimer',
		'UnpauseTimer',
		'Draw',
		'SetAllianceStatus',
		'DisableDebugMode',
		'EnableDebugMode'
	]
	longlabel = 17

	def __init__(self, stat_txt=None, aiscript=None, bwscript=None):
		if stat_txt == None:
			stat_txt = os.path.join('Default','stat_txt.tbl')
		if aiscript == None:
			aiscript = os.path.join('Default','aiscript.bin')
		if bwscript == None:
			bwscript = os.path.join('Default','bwscript.bin')
		self.triggers = []
		self.strings = {}
		self.properties = {}
		self.stat_txt = TBL.TBL()
		self.stat_txt.load_file(stat_txt)
		ais = AIBIN.AIBIN(stat_txt=stat_txt)
		ais.load_file(aiscript)
		# aiscript - ai, ailoc
		# bwscript - ai, ailoc
		self.ais = [[odict(),odict()],[odict(),odict()]]
		self.ais_rev = [[odict(),odict()],[odict(),odict()]]
		for name,data in ais.ais.iteritems():
			string = TBL.decompile_string(self.stat_txt.strings[data[1]].split('\x00',1)[0])
			self.ais[not not data[2] & 4][data[2] & 1][name] = string
			self.ais_rev[not not data[2] & 4][data[2] & 1][string] = name
		self.condition_parameters = [
			None,
			[self.condition_comparison, self.condition_number],
			[self.condition_player, self.condition_comparison, self.condition_number, self.condition_tunit],
			[self.condition_player, self.condition_comparison, self.condition_number, self.condition_tunit, self.condition_location],
			[self.condition_player, self.condition_comparison, self.condition_number, self.condition_restype],
			[self.condition_player, self.condition_comparison, self.condition_number, self.condition_tunit],
			[self.condition_tunit],
			[self.condition_tunit, self.condition_location],
			[self.condition_tunit],
			[self.condition_score],
			[self.condition_restype],
			[self.condition_switch, self.condition_set],
			[self.condition_comparison, self.condition_number],
			None,
			[self.condition_player, self.condition_comparison, self.condition_number],
			[self.condition_player, self.condition_tunit, self.condition_comparison, self.condition_number],
			[self.condition_tunit],
			[self.condition_tunit, self.condition_location],
			[self.condition_tunit],
			[self.condition_score],
			[self.condition_restype],
			[self.condition_player, self.condition_comparison, self.condition_number, self.condition_score],
			None,
			None
		]
		self.action_parameters = [
			None,
			None,
			None,
			None,
			[self.action_time],
			None,
			None,
			[self.action_string, self.action_wav, self.action_time, self.action_unit, self.action_location, self.action_modifier, self.action_time],
			[self.action_wav, self.action_time],
			[self.action_string, self.action_display],
			[self.action_location],
			[self.action_player, self.action_number, self.action_unit, self.action_location, self.action_property],
			[self.action_string],
			[self.action_switch, self.action_switchaction],
			[self.action_modifier, self.action_time],
			[self.action_aiscript],
			[self.action_aiscript_loc, self.action_location],
			[self.action_string, self.action_tunit],
			[self.action_string, self.action_tunit, self.action_location],
			[self.action_string, self.action_restype],
			[self.action_string, self.action_tunit],
			[self.action_string, self.action_score],
			[self.action_player, self.action_tunit],
			[self.action_player, self.action_qnumber, self.action_tunit, self.action_location],
			[self.action_player, self.action_tunit],
			[self.action_player, self.action_qnumber, self.action_tunit, self.action_location],
			[self.action_player, self.action_modifier, self.action_number, self.action_restype],
			[self.action_player, self.action_modifier, self.action_number, self.action_score],
			[self.action_location],
			[self.action_unit, self.action_time],
			None,
			None,
			[self.action_state],
			[self.action_string, self.action_number, self.action_tunit],
			[self.action_string, self.action_number, self.action_tunit, self.action_location],
			[self.action_string, self.action_number, self.action_tunit, self.action_restype],
			[self.action_string, self.action_number, self.action_tunit],
			[self.action_string, self.action_number, self.action_score],
			[self.action_player, self.action_tunit, self.action_location, self.action_destlocation],
			[self.action_player, self.action_qnumber, self.action_tunit, self.action_location, self.action_destlocation],
			[self.action_number],
			[self.action_string],
			[self.action_player, self.action_tunit, self.action_location, self.action_state],
			[self.action_player, self.action_tunit, self.action_location, self.action_state],
			[self.action_player, self.action_number, self.action_unit, self.action_location],
			[self.action_player, self.action_tunit, self.action_modifier, self.action_number],
			[self.action_player, self.action_tunit, self.action_location, self.action_order, self.action_destlocation],
			[self.action_string],
			[self.action_player, self.action_destplayer, self.action_qnumber, self.action_tunit, self.action_location],
			[self.action_player, self.action_qnumber, self.action_tunit, self.action_location, self.action_percentage],
			[self.action_player, self.action_qnumber, self.action_tunit, self.action_location, self.action_percentage],
			[self.action_player, self.action_qnumber, self.action_tunit, self.action_location, self.action_percentage],
			[self.action_player, self.action_qnumber, self.action_location, self.action_percentage],
			[self.action_player, self.action_number, self.action_tunit, self.action_location, self.action_percentage],
			None,
			None,
			None,
			[self.action_player, self.action_allystatus],
			None,
			None
		]

	def load_file(self, file, TRIG=False):
		try:
			f = open(file,'rb')
			data = f.read()
			f.close()
		except:
			raise PyMSError('Load',"Could not load TRG '%s'" % file)
		try:
			offset = 0
			if not TRIG:
				if data[:8] != 'qw\x986\x18\x00\x00\x00':
					raise PyMSError('Load',"'%s' is not a TRG file (no TRG header). It could possibly be a .got TRG file, try using the -t option when decompiling" % file)
				offset = 8
			triggers = []
			strings = {}
			properties = {}
			findnext = []
			while offset < len(data):
				if not findnext:
					conditions = []
					for c in range(16):
						condition = struct.unpack('<3LH4B', data[offset:offset+18])
						if c and not condition[5]:
							break
						if self.condition_parameters[condition[5]]:
							for parameter in self.condition_parameters[condition[5]]:
								parameter(True, condition)
						conditions.append(list(condition))
						offset += 20
					offset += 20 * (16 - len(conditions))
					actions = []
					for a in range(64):
						action = struct.unpack('<6LH3B', data[offset:offset+29])
						if a and not action[7]:
							break
						if not TRIG:
							if action[1]:
								findnext.append([True,action[1]])
							if  action[7] == 11 and action[9] & 8:
								findnext.append([False,action[5]])
						if self.action_parameters[action[7]]:
							for parameter in self.action_parameters[action[7]]:
								parameter(True, action, {}, {})
						actions.append(list(action))
						offset += 32
					offset += 32 * (64 - len(actions))
					if not conditions == [[0,0,0,0,0,0,0,0]] or not actions == [[0,0,0,0,0,0,0,0,0,0]]:
						triggers.append([list(struct.unpack('<4x28B', data[offset:offset+32])),conditions,actions])
					offset += 32
				else:
					if findnext[0][0]:
						strings[findnext[0][1]] = data[offset:offset+2048].split('\x00',1)[0]
						if len(strings[findnext[0][1]]) < 2048:
							strings[findnext[0][1]] += '\x00'
						offset += 2048
					else:
						properties[findnext[0][1]] = list(struct.unpack('<HH4BLHH', data[offset:offset+16]))
						offset += 20
					del findnext[0]
			d = open('trgdebug.txt','w')
			for t in triggers:
				d.write(str(t) + '\n')
			d.close()
			self.triggers = triggers
			self.strings = strings
			self.properties = properties
		except PyMSError:
			raise
		except:
			raise
			raise PyMSError('Load',"Unsupported TRG file '%s', could possibly be corrupt" % file)

	def condition_number(self, decompile, condition, data=None):
		"""Number       - Any number in the range 0 to 4294967295"""
		if decompile:
			return condition[2]
		try:
			n = int(data)
			if -1 < n < 4294967296:
				condition[2] = n
				return
		except:
			pass
		raise PyMSError('Parameter',"'%s' is an invalid Number (value must be in the range 0 to 4294967295)" % data)

	def condition_player(self, decompile, condition, data=None):
		"""Player       - A number in the range 0 to 255 (with or without the keyword Player before it), or any keyword from this list: Current Player, Foes, Allies, Neutral Players, All Players, Force 1, Force 2, Force 3, Force 4, Unused 1, Unused 2, Unused 3, Unused 4, Non Allied Victory Players"""
		if decompile:
			if condition[1] < 27:
				return player_ids[condition[1]]
			return condition[1]
		if data in player_ids:
			condition[1] = player_ids.index(data)
			return
		try:
			p = int(data)
			if -1 < p < 256:
				condition[1] = p
			return
		except:
			pass
		raise PyMSError('Parameter',"'%s' is an invalid Player (value must be in the range 0 to 255, or on of the keywords: Current Player, Foes, Allies, Neutral Players, All Players, Force 1, Force 2, Force 3, Force 4, Unused 1, Unused 2, Unused 3, Unused 4, Non Allied Victory Players)" % data)

	def condition_comparison(self, decompile, condition, data=None):
		"""Comparison   - One of the keywords: At Least, Exactly, At Most"""
		if decompile:
			if not condition[4]:
				return 'At Least'
			elif condition[4] == 1:
				return 'At Most'
			elif condition[4] == 10:
				return 'Exactly'
			raise
		if data in ['At Least','Exactly','At Most']:
			if data == 'At Least':
				condition[4] = 0
			elif data == 'At Most':
				condition[4] = 1
			else:
				condition[4] = 10
			return
		raise PyMSError('Parameter',"'%s' is an invalid Comparison (value must be one of the keywords: At Least, Exactly, At Most)" % data)

	def condition_tunit(self, decompile, condition, data=None):
		"""TUnit        - A unit ID from 0 to 227 (and extended unit ID 233 to 65535), a full unit name (in the TBL, its the part before the first <0>), or a type from the list: None, Any Unit, Men, Buildings, Factories"""
		if decompile:
			if -1 < condition[3] < 228:
				s = self.stat_txt.strings[condition[3]].split('\x00')
				if s[1] != '*':
					return TBL.decompile_string('\x00'.join(s[:2]))
				else:
					return TBL.decompile_string(s[0])
			if condition[3] < 233:
				return unit_types[condition[3] - 228]
			return condition[3]
		if data in unit_types:
			condition[3] = unit_types.index(data) + 228
			condition[7] ^= 16
			return
		try:
			u = int(data)
			if -1 < u < 65536:
				condition[3] = u
				return
		except:
			pass
		for i,name in enumerate(self.stat_txt.strings[:228]):
			n = name.split('\x00')
			if TBL.compile_string(data) == n[0] or (n[1] != '*' and TBL.compile_string(data) == '\x00'.join(n)):
				condition[3] = i
				return
		raise PyMSError('Parameter',"'%s' is an invalid TUnit (value must be in the range 0 to 227, a full unit name, or a type from the list: None, Any Unit, Men, Buildings, Factories)" % data)

	def condition_location(self, decompile, condition, data=None):
		"""Location     - A number in the range 0 to 255 (with or without the keyword Location before it), or the keyword Anywhere"""
		if decompile:
			if condition[0] == 64:
				return 'Anywhere'
			return 'Location %s' % condition[0]
		if condition == 'Anywhere':
			condition[0] = 64
			return
		else:
			l = None
			try:
				if data.startswith('Location '):
					l = int(data.split(' ',1)[1])
				else:
					l = int(data)
			except:
				pass
			if l != None and -1 < l < 256:
				condition[0] = l
				return
		raise PyMSError('Parameter',"'%s' is an invalid Location (value must be in the range 0 to 255, or the keyword Anywhere)" % data)

	def condition_restype(self, decompile, condition, data=None):
		"""ResType      - One of the keywords: Ore, Gas, Ore and Gas"""
		if decompile:
			return resource_types[condition[6]]
		if data in resource_types:
			condition[6] = resource_types.index(data)
			return
		raise PyMSError('Parameter',"'%s' is an invalid ResType (value must be one of the keywords: Ore, Gas, Ore and Gas)" % data)

	def condition_score(self, decompile, condition, data=None):
		"""ScoreType    - One of the keywords: Total, Units, Buildings, Units and Buildings, Kills, Razings, Kills and Razings, Custom"""
		if decompile:
			return score_types[condition[6]]
		if data in score_types:
			condition[6] = score_types.index(data)
			return
		raise PyMSError('Parameter',"'%s' is an invalid Score (value must be one of the keywords: Total, Units, Buildings, Units and Buildings, Razings, Kills and Razings, Custom)" % data)

	def condition_switch(self, decompile, condition, data=None):
		"""Switch       - A number in the range 0 to 255 (with or without the keyword Switch before it)"""
		if decompile:
			return 'Switch %s' % condition[6]
		l = None
		try:
			if data.startswith('Switch '):
				l = int(data.split(' ',1)[1])
			else:
				l = int(data)
		except:
			pass
		if l != None and -1 < l < 256:
			condition[6] = l
			return
		raise PyMSError('Parameter',"'%s' is an invalid Switch (value must be in the range 0 to 255)" % data)

	def condition_set(self, decompile, condition, data=None):
		"""Set          - Either the keyword Set, or Cleared"""
		if decompile:
			if condition[4] == 2:
				return 'Set'
			elif condition[4] == 3:
				return 'Cleared'
			raise
		if data in ['Set','Cleared']:
			if data == 'Set':
				condition[4] = 2
			else:
				condition[4] = 3
			return
		raise PyMSError('Parameter',"'%s' is an invalid Set (value must be one of the keywords: Set, Cleared)" % data)

	def action_time(self, decompile, action, strings, properties, data=None):
		"""Time         - Like number, can be any number in the range 0 to 4294967295"""
		if decompile:
			return action[3]
		try:
			t = int(data)
			if -1 < t < 4294967296:
				action[3] = t
				return
		except:
			pass
		raise PyMSError('Parameter',"'%s' is an invalid Time (value must be in the range 0 to 4294967295)" % data)

	def action_string(self, decompile, action, strings, properties, data=None):
		"""String       - A number corrisponding to a string (with or without the keyword String before it)"""
		if decompile:
			return 'String %s' % action[1]
		s = None
		try:
			if data.startswith('String '):
				s = int(data.split(' ',1)[1])
			else:
				s = int(data)
		except:
			pass
		if s != None and s in strings:
			action[1] = s
			return
		raise PyMSError('Parameter',"'%s' is an invalid String (value must be a number corrisponding to a string)" % data)

	def action_unit(self, decompile, action, strings, properties, data=None):
		"""Unit         - Like TUnit, but only accepts a unit ID from 0 to 227 (and extended unit ID's 228 to 65536), or a full unit name (in the TBL, its the part before the first <0>)"""
		if decompile:
			if action[6] < 228:
				s = self.stat_txt.strings[action[6]].split('\x00')
				if s[1] != '*':
					return TBL.decompile_string('\x00'.join(s[:2]))
				else:
					return TBL.decompile_string(s[0])
			return action[6]
		try:
			i = int(data)
			if -1 < i < 65536:
				action[6] = i
				return
		except:
			pass
		for i,name in enumerate(self.stat_txt.strings[:228]):
			n = name.split('\x00')
			if TBL.compile_string(data) == n[0] or (n[1] != '*' and TBL.compile_string(data) == '\x00'.join(n)):
				action[6] = i
				return
		raise PyMSError('Parameter',"'%s' is an invalid Unit (value must be in the range 0 to 227, or a full unit name)" % data)

	def action_location(self, decompile, action, strings, properties, data=None):
		"""Location"""
		if decompile:
			if action[0] == 64:
				return 'Anywhere'
			return 'Location %s' % action[0]
		if data == 'Anywhere':
			action[0] = 64
			return
		l = None
		try:
			if data.startswith('Location '):
				l = int(data.split(' ',1)[1])
			else:
				l = int(data)
		except:
			pass
		if l != None and -1 < l < 256:
			action[0] = l
			return
		raise PyMSError('Parameter',"'%s' is an invalid Location (value must be in the range 0 to 255, or the keyword Anywhere)" % data)

	def action_destlocation(self, decompile, action, strings, properties, data=None):
		"""DestLocation - A number in the range 0 to 255 (with or without the keyword Location before it), or the keyword Anywhere"""
		if decompile:
			if action[5] == 64:
				return 'Anywhere'
			return 'Location %s' % action[5]
		if data == 'Anywhere':
			action[5] = 64
			return
		l = None
		try:
			if data.startswith('Location '):
				l = int(data.split(' ',1)[1])
			else:
				l = int(data)
		except:
			pass
		if l != None and -1 < l < 256:
			action[5] = l
			return
		raise PyMSError('Parameter',"'%s' is an invalid DestLocation (value must be in the range 0 to 255, or the keyword Anywhere)" % data)

	def action_modifier(self, decompile, action, strings, properties, data=None):
		"""Modifier     - One of the keywords: Set To, Add, Subtract"""
		if decompile:
			if action[8] == 7:
				return 'Set To'
			elif action[8] == 8:
				return 'Add'
			elif action[8] == 9:
				return 'Subtract'
			raise
		if data in ['Set To', 'Add', 'Subtract']:
			if data == 'Set To':
				action[8] = 7
			elif data == 'Add':
				action[8] = 8
			else:
				action[8] = 9
			return
		raise PyMSError('Parameter',"'%s' is an invalid Modifier (value must be one of the keywords: Set To, Add, Subtract)" % data)

	def action_wav(self, decompile, action, strings, properties, data=None):
		"""WAV          - A number corrisponding to a WAV (with or without the keyword WAV before it)"""
		if decompile:
			return 'WAV %s' % action[2]
		s = None
		try:
			if data.startswith('WAV '):
				s = int(data.split(' ',1)[1])
			else:
				s = int(data)
		except:
			pass
		if s != None and s in strings:
			action[2] = s
			return
		raise PyMSError('Parameter',"'%s' is an invalid WAV (value must be a number corrisponding to a string)" % data)

	def action_display(self, decompile, action, strings, properties, data=None):
		"""Display      - Either the keyword Always Display, or Only With Subtitles"""
		if decompile:
			if action[9] & 4:
				return 'Always Display'
			return 'Only With Subtitles'
		if data == 'Always Display':
			action[9] ^= 4
			return
		elif data == 'Only With Subtitles':
			return
		raise PyMSError('Parameter',"'%s' is an invalid Display type (value must be one of the keywords: Always Display, Only With Subtitles)" % data)

	def action_player(self, decompile, action, strings, properties, data=None):
		"""Player"""
		if decompile:
			if action[4] < 27:
				return player_ids[action[4]]
			return action[4]
		if data in player_ids:
			action[4] = player_ids.index(data)
			return
		try:
			p = int(data)
			if -1 < p < 256:
				action[4] = p
				return
		except:
			pass
		raise PyMSError('Parameter',"'%s' is an invalid Player (value must be in the range 0 to 255, or on of the keywords: Current Player, Foes, Allies, Neutral Players, All Players, Force 1, Force 2, Force 3, Force 4, Unused 1, Unused 2, Unused 3, Unused 4, Non Allied Victory Players)" % data)

	def action_destplayer(self, decompile, action, strings, properties, data=None):
		"""DestPlayer   - A number in the range 0 to 255 (with or without the keyword Player before it), or any keyword from this list: Current Player, Foes, Allies, Neutral Players, All Players, Force 1, Force 2, Force 3, Force 4, Unused 1, Unused 2, Unused 3, Unused 4, Non Allied Victory Players"""
		if decompile:
			if action[5] < 27:
				return player_ids[action[5]]
			return action[5]
		if data in player_ids:
			action[5] = player_ids.index(data)
			return
		try:
			p = int(data)
			if -1 < p < 256:
				action[5] = p
				return
		except:
			pass
		raise PyMSError('Parameter',"'%s' is an invalid DestPlayer (value must be in the range 0 to 255, or on of the keywords: Current Player, Foes, Allies, Neutral Players, All Players, Force 1, Force 2, Force 3, Force 4, Unused 1, Unused 2, Unused 3, Unused 4, Non Allied Victory Players)" % data)

	def action_number(self, decompile, action, strings, properties, data=None):
		"""Number"""
		if decompile:
			return action[5]
		try:
			n = int(data)
			if -1 < n < 4294967296:
				action[5] = n
				return
		except:
			pass
		raise PyMSError('Parameter',"'%s' is an invalid Number (value must be in the range 0 to 4294967295)" % data)

	def action_qnumber(self, decompile, action, strings, properties, data=None):
		"""QNumber      - Any number in the range 1 to 4294967295, or the keyword All"""
		if decompile:
			if action[8]:
				return action[8]
			return 'All'
		if data == 'All':
			action[5] = 0
			return
		try:
			n = int(data)
			if 0 < n < 256:
				action[8] = n
				return
		except:
			pass
		raise PyMSError('Parameter',"'%s' is an invalid QNumber (value must be in the range 1 to 255, or the keyword All)" % data)

	def action_property(self, decompile, action, strings, properties, data=None):
		"""Property     - A number corrisponding to a Property (with or without the keyword Property before it)"""
		if decompile:
			return 'Property %s' % action[5]
		p = None
		try:
			if data.startswith('Property '):
				p = int(data.split(' ',1)[1])
			else:
				p = int(data)
		except:
			pass
		if p != None and p in properties:
			action[5] = p
			action[9] ^= 8
			return
		raise PyMSError('Parameter',"'%s' is an invalid Property (value must be a number corrisponding to a property)" % data)

	def action_switch(self, decompile, action, strings, properties, data=None):
		"""Switch"""
		if decompile:
			return 'Switch %s' % action[5]
		s = None
		try:
			if data.startswith('Switch '):
				s = int(data.split(' ',1)[1])
			else:
				s = int(data)
		except:
			pass
		if -1 < s < 256:
			action[5] = s
			return
		raise PyMSError('Parameter',"'%s' is an invalid Switch (value must be in the range 0 to 255)" % data)

	def action_switchaction(self, decompile, action, strings, properties, data=None):
		"""SwitchAction - One of the keywords: Set, Clear, Toggle, Randomize"""
		if decompile:
			if action[8] == 4:
				return 'Set'
			elif action[8] == 5:
				return 'Clear'
			elif action[8] == 6:
				return 'Toggle'
			elif action[8] == 11:
				return 'Randomize'
			raise
		if data in ['Set','Clear','Toggle','Randomize']:
			if data == 'Set':
				action[8] = 4
			elif data == 'Clear':
				action[8] = 5
			elif data == 'Toggle':
				action[8] = 6
			else:
				action[8] = 11
			return
		raise PyMSError('Parameter',"'%s' is an invalid SwitchAction (value must be one of the keywords: Set, Clear, Toggle, Randomize)" % data)

	def action_aiscript(self, decompile, action, strings, properties, data=None):
		"""AIScript     - The name of an AIScript (a list of all the AIScript values is given below)"""
		if decompile:
			ai = struct.pack('<L', action[5])
			if ai in self.ais[0][0]:
				return self.ais[0][0][ai]
			if ai in self.ais[1][0]:
				return self.ais[1][0][ai]
			return ai
		if data in self.ais_rev[0][0]:
			action[5] = struct.unpack('<L',self.ais_rev[0][0][data])[0]
			return
		if data in self.ais_rev[1][0]:
			action[5] = struct.unpack('<L',self.ais_rev[1][0][data])[0]
			return
		if len(data) == 4:
			action[5] = struct.unpack('<L',data)[0]
			return
		raise PyMSError('Parameter',"'%s' is an invalid AIScript (value must be an AIScript, check the reference for a list)" % data)

	def action_aiscript_loc(self, decompile, action, strings, properties, data=None):
		"""AIScriptLoc  - The name of a location based AIScript (a list of all location based AIScripts is given below)"""
		if decompile:
			ai = struct.pack('<L', action[5])
			if ai in self.ais[0][1]:
				return self.ais[0][1][ai]
			if ai in self.ais[1][1]:
				return self.ais[1][1][ai]
			return ai
		if data in self.ais_rev[0][1]:
			action[5] = struct.unpack('<L',self.ais_rev[0][1][data])[0]
			return
		if data in self.ais_rev[1][1]:
			action[5] = struct.unpack('<L',self.ais_rev[1][1][data])[0]
			return
		if len(data) == 4:
			action[5] = struct.unpack('<L',data)[0]
			return
		raise PyMSError('Parameter',"'%s' is an invalid AIScriptLoc (value must be an AIScript, check the reference for a list)" % data)

	def action_tunit(self, decompile, action, strings, properties, data=None):
		"""TUnit"""
		if decompile:
			if -1 < action[6] < 228:
				s = self.stat_txt.strings[action[6]].split('\x00')
				if s[1] != '*':
					return TBL.decompile_string('\x00'.join(s[:2]))
				else:
					return TBL.decompile_string(s[0])
			if action[6] < 233:
				return unit_types[action[6] - 228]
			return action[6]
		if data in unit_types:
			action[6] = unit_types.index(data) + 228
			action[9] ^= 16
			return
		try:
			i = int(data)
			if -1 < i < 65536:
				action[6] = i
				return
		except:
			pass
		for i,name in enumerate(self.stat_txt.strings[:228]):
			n = name.split('\x00')
			if TBL.compile_string(data) == n[0] or (n[1] != '*' and TBL.compile_string(data) == '\x00'.join(n)):
				action[6] = i
				return
		raise PyMSError('Parameter',"'%s' is an invalid TUnit value must be in the range 0 to 227, a full unit name, or a type from the list: None, Any Unit, Men, Buildings, Factories)" % data)

	def action_restype(self, decompile, action, strings, properties, data=None):
		"""ResType"""
		if decompile:
			return resource_types[action[6]]
		if data in resource_types:
			action[6] = resource_types.index(data)
			return
		raise PyMSError('Parameter',"'%s' is an invalid ResType (value must be one of the keywords: Ore, Gas, Ore and Gas)" % data)

	def action_score(self, decompile, action, strings, properties, data=None):
		"""ScoreType"""
		if decompile:
			return score_types[action[6]]
		if data in score_types:
			action[6] = score_types.index(data)
			return
		raise PyMSError('Parameter',"'%s' is an invalid ScoreType (value must be one of the keywords: Total, Units, Buildings, Units and Buildings, Razings, Kills and Razings, Custom)" % data)

	def action_state(self, decompile, action, strings, properties, data=None):
		"""State        - One of the keywords: Set, Clear, Toggle"""
		if decompile:
			if action[8] == 4:
				return 'Set'
			elif action[8] == 5:
				return 'Clear'
			elif action[8] == 6:
				return 'Toggle'
			raise
		if data in ['Set','Clear','Toggle']:
			if data == 'Set':
				action[8] = 4
			elif data == 'Clear':
				action[8] = 5
			else:
				action[8] = 6
			return
		raise PyMSError('Parameter',"'%s' is an invalid State (value must be one of the keywords: Set, Clear, Toggle)" % data)

	def action_order(self, decompile, action, strings, properties, data=None):
		"""Order        - One of the keywords: Move, Patroll, Attack"""
		if decompile:
			return unit_orders[action[8]]
		if data in unit_orders:
			action[8] = unit_orders.index(data)
		raise PyMSError('Parameter',"'%s' is an invalid Order (value must be one of the keywords: Move, Patroll, Attack)" % data)

	def action_percentage(self, decompile, action, strings, properties, data=None):
		"""Percentage   - A number from 0 to 100 (with or without a trailing %)"""
		if decompile:
			if action[5] > 100:
				raise
			return '%s%%' % action[5]
		try:
			if data.endswith('%'):
				p = int(data[:-1])
			else:
				p = int(data)
			if -1 < t < 101:
				action[2] = p
				return
		except:
			pass
		raise PyMSError('Parameter',"'%s' is an invalid Percentage (value must be in the range 0 to 100)" % data)

	def action_allystatus(self, decompile, action, strings, properties, data=None):
		"""AllyStatus   - One of the keywords: Enemy, Ally, Allied Victory"""
		if decompile:
			return ally_status[action[6]]
		if data in ally_status:
			action[6] = ally_status.index(data)
			return
		raise PyMSError('Parameter',"'%s' is an invalid AllyStatus (value must be one of the keywords: Enemy, Ally, Allied Victory)" % data)

	def interpret(self, file): 
		try:
			f = open(file,'r')
			data = f.readlines()
			f.close()
		except:
			raise PyMSError('Interpreter',"Could not load file '%s'" % file)
		triggers = []
		strings = {}
		properties = {}
		constants = {}
		conditions = {}
		actions = {}
		def param_constant(o):
			if o.group(1) in constants:
				return constants[o.group(1)]
			return o.group(0)
		# 0 = Nothing, 1 = String, 2 = Property
		# 3 = Trigger, 4 = Conditions, 5 = End Conditions, 6 = Actions
		# 7 = Constant, 8 = Conditions Function, 9 = Actions Function
		id = 0
		state = 0
		for n,l in enumerate(data):
			if len(l) > 1:
				line = l.strip().split('#',1)[0]
				if line:
					if state == 1:
						if l.endswith('\n'):
							l = l[:-1]
						strings[id] += TBL.compile_string(l).split('\x00')[0]
						if len(strings[id]) > 2047:
							raise PyMSError('Interpreter',"String '%s' is too long (max length is 2048 characters)" % id,n,line)
						if re.match('.*<0+>.*', l):
							state = 0
							strings[id] += '\x00'
						else:
							strings[id] += '\n'
						continue
					elif state == 2:
						match = re.match('\\A(.+)\\((.+)\\)\\s*\\Z', line)
						if match:
							cmd = match.group(1)
							dat = match.group(2)
							if cmd == 'ValidProperties':
								if properties[id][0] != None:
									raise PyMSError('Interpreter',"Property '%s' has more then one ValidProperties setting" % id,n,line)
								properties[id][0] = 0
								if dat:
									params = re.split('\\s*,\\s*', dat)
									for param in params:
										if not param in unit_properties:
											raise PyMSError('Interpreter',"Property '%s' has an invalid ValidProperties value: '%s'" % (id,param),n,line)
										properties[id][0] ^= 2 ** unit_properties.index(param)
							elif cmd == 'ValidUnitData':
								if properties[id][1] != None:
									raise PyMSError('Interpreter',"Property '%s' has more then one ValidUnitData setting" % id,n,line)
								properties[id][1] = 0
								if dat:
									params = re.split('\\s*,\\s*', dat)
									for param in params:
										if not param in unit_data:
											raise PyMSError('Interpreter',"Property '%s' has an invalid ValidUnitData value: '%s'" % (id,param),n,line)
										properties[id][1] ^= 2 ** unit_data.index(param)
								for n in range(6):
									if not properties[id][1] & (2 ** n):
										properties[id][2 + n] = 0
							elif cmd == 'Properties':
								if properties[id][0] == None:
									raise PyMSError('Interpreter',"Property '%s' is trying to set the Properties before declaring the ValidProperties" % id,n,line)
								if properties[id][8] != None:
									raise PyMSError('Interpreter',"Property '%s' has more then one Properties setting" % id,n,line)
								properties[id][8] = 0
								if dat:
									params = re.split('\\s*,\\s*', dat)
									for param in params:
										if not param in unit_properties:
											raise PyMSError('Interpreter',"Property '%s' has an invalid Properties value: '%s'" % (id,param),n,line)
										properties[id][8] ^= 2 ** unit_properties.index(param)
							elif cmd in unit_data:
								if properties[id][1] == None:
									raise PyMSError('Interpreter',"Property '%s' is trying to set some unit data before declaring the ValidUnitData" % id,n,line)
								if properties[id][unit_data.index(cmd) + 2] != None:
									raise PyMSError('Interpreter',"Property '%s' has more then on %s setting" % (id,cmd),n,line)
								if cmd in ['Owner', 'Resources', 'AmountInHanger', 'Unknown']:
									try:
										d = int(dat)
									except:
										raise PyMSError('Interpreter',"Property '%s' has an invalid %s value: '%s'" % (id,cmd,dat),n,line)
									if cmd == 'Resources' and (-1 > p or 4294967295 < p):
										raise PyMSError('Interpreter',"Property '%s' has an invalid Resources value: '%s' (Must be a value between 0 and 4294967295)" % (id,p),n,line)
									elif cmd == 'AmountInHanger' and (-1 > p or 10 < p):
										raise PyMSError('Interpreter',"Property '%s' has an invalid AmountInHanger value: '%s' (Must be a value between 0 and 10)" % (id,p),n,line)
								elif cmd in ['Health','Shields','Energy']:
									try:
										if dat.endswith('%'):
											d = int(dat[:-1])
										else:
											d = int(dat)
									except:
										raise PyMSError('Interpreter',"Property '%s' has an invalid %s value: '%s'" % (id,cmd,dat),n,line)
									if -1 > d or 100 < d:
										raise PyMSError('Interpreter',"Property '%s' has an invalid %s value: '%s' (Must be a value between 0 and 100)" % (id,cmd,p),n,line)
								properties[id][unit_data.index(cmd) + 2] = d
							else:
								raise PyMSError('Interpreter',"Property '%s' has an unknown line format" % id,n,line)
							if not None in properties[id]:
								state = 0
						else:
							raise PyMSError('Interpreter',"Property '%s' has an unknown line format" % id,n,line)
						continue
					elif state == 3:
						if line != 'Conditions:':
							raise PyMSError('Interpreter',"Unexpected line, expected 'Conditions:'",n,line)
						state = 4
						continue
					elif state in [4,8]:
						if state == 4 and line == 'Actions:':
							state = 6
							continue
						cont = True
						for r in ['\\AString (\\d+):\\s*\\Z','\\AProperty (\\d+):\\s*\\Z','\\ATrigger(.+):\\s*\\Z','\\AConstant ([^\s]+):\\s*\\Z','\\AConditions ([^\s]+):\\s*\\Z','\\AActions ([^\s]+):\\s*\\Z']:
							match = re.match(r, line)
							if match:
								if state != 8:
									raise PyMSError('Interpreter',"Unexpected line, expected a condition or 'Actions:'",n,line)
								cont = False
								break
						if cont:
							match = re.match('\\A(-)?(.+)\\((.+)?\\)\\s*\\Z', line)
							if match:
								condition = [0]*8
								if match.group(1):
									condition[7] ^= 2
								cmd = match.group(2)
								if cmd in conditions:
									if state == 8:
										raise PyMSError('Interpreter',"You can not access a Condition Function inside another Condition Function",n,line)
									if len(triggers[-1][1]) + len(conditions[cmd]) > 16:
										raise PyMSError('Interpreter',"The Condition Function '%s' makes the trigger have over 16 conditions" % cmd,n,line)
									triggers[-1][1].extend(conditions[cmd])
								else:
									dat = []
									if match.group(3):
										dat = re.split('\\s*,\\s*', re.sub('\\{([^}\s]+)\\}', param_constant, match.group(3)))
									if not cmd in self.conditions:
										raise PyMSError('Interpreter',"'%s' is an invalid condition" % cmd,n,line)
									condition[5] = self.conditions.index(cmd)
									params = self.condition_parameters[condition[5]]
									if params and len(dat) != len(params):
										raise PyMSError('Interpreter',"Incorrect parameter amount for condition '%s' (expected %s, got %s)" % (cmd,len(params),len(dat)),n,line)
									elif not params and dat:
										raise PyMSError('Interpreter',"The condition '%s' takes no paramaters, but got %s" % (cmd,len(dat)),n,line)
									elif params and dat:
										for d,param in zip(dat,params):
											try:
												param(False, condition, d)
											except PyMSError, e:
												e.line = n
												e.code = line
												raise
									if state == 8:
										conditions[id].append(condition)
										if len(conditions[id]) == 16:
											state = 0
									else:
										triggers[-1][1].append(condition)
										if len(triggers[-1][1]) == 16:
											state = 5
							else:
								raise PyMSError('Interpreter',"Unexpected line, expected a condition",n,line)
							continue
					elif state == 5:
						if line != 'Actions:':
							raise PyMSError('Interpreter',"Unexpected line, expected 'Actions:'",n,line)
						state = 6
						continue
					elif state in [6,9]:
						cont = True
						for r in ['\\AString (\\d+):\\s*\\Z','\\AProperty (\\d+):\\s*\\Z','\\ATrigger(.+):\\s*\\Z','\\AConstant ([^\s]+):\\s*\\Z','\\AConditions ([^\s]+):\\s*\\Z','\\AActions ([^\s]+):\\s*\\Z']:
							match = re.match(r, line)
							if match:
								cont = False
								break
						if cont:
							match = re.match('\\A(-)?(.+)\\((.+)?\\)\\s*\\Z', line)
							if match:
								action = [0]*10
								if match.group(1):
									action[9] ^= 2
								cmd = match.group(2)
								if cmd in actions:
									if state == 9:
										raise PyMSError('Interpreter',"You can not access an Action Function inside another Action Function",n,line)
									if len(triggers[-1][2]) + len(actions[cmd]) > 64:
										raise PyMSError('Interpreter',"The Action Function '%s' makes the trigger have more then 64 actions" % cmd,n,line)
									triggers[-1][2].extend(actions[cmd])
								else:
									dat = []
									if match.group(3):
										dat = re.split('\\s*,\\s*', re.sub('\\{([^}\s]+)\\}', param_constant, match.group(3)))
									if not cmd in self.actions:
										raise PyMSError('Interpreter',"'%s' is an invalid action" % cmd,n,line)
									action[7] = self.actions.index(cmd)
									params = self.action_parameters[action[7]]
									if params and len(dat) != len(params):
										raise PyMSError('Interpreter',"Incorrect parameter amount for action '%s' (expected %s, got %s)" % (cmd,len(params),len(dat)),n,line)
									if not params and dat:
										raise PyMSError('Interpreter',"The action '%s' takes no paramaters, but got %s" % (cmd,len(dat)),n,line)
									elif params and dat:
										for d,param in zip(dat,params):
											try:
												param(False, action, strings, properties, d)
											except PyMSError, e:
												e.line = n
												e.code = line
												raise
									if state == 9:
										actions[id].append(action)
										if len(actions[id]) == 64:
											state = 0
									else:
										triggers[-1][2].append(action)
										if len(triggers[-1][2]) == 64:
											state = 0
							else:
								raise PyMSError('Interpreter',"Unexpected line, expected an action",n,line)
							continue
					elif state == 7:
						if l.endswith('\n'):
							l = l[:-1]
						constants[id] = l
						state = 0
						continue
					match = re.match('\\AString (\\d+):\\s*\\Z', line)
					if match:
						try:
							id = int(match.group(1))
						except:
							raise PyMSError('Interpreter',"Invalid string number '%s'" % match.group(1),n,line)
						if id in strings:
							raise PyMSError('Interpreter',"There is already a string with id number '%s'" % id,n,line)
						strings[id] = ''
						state = 1
						continue
					match = re.match('\\AProperty (\\d+):\\s*\\Z', line)
					if match:
						try:
							id = int(match.group(1))
						except:
							raise PyMSError('Interpreter',"Invalid property number '%s'" % match.group(1),n,line)
						if id in properties:
							raise PyMSError('Interpreter',"There is already a property with id number '%s'" % id,n,line)
						properties[id] = [None]*9
						state = 2
						continue
					match = re.match('\\ATrigger\\((.+)\\):\\s*\\Z', line)
					if match:
						triggers.append([[0]*28,[],[]])
						params = re.split('\\s*,\\s*', match.group(1))
						for param in params:
							if not param in player_ids:
								raise PyMSError('Interpreter',"Invalid player id '%s'" % param,n,line)
							triggers[-1][0][player_ids.index(param)] = 1
						state = 3
						continue
					match = re.match('\\AConstant ([^\s]+):\\s*\\Z', line)
					if match:
						id = match.group(1)
						state = 7
						continue
					match = re.match('\\AConditions ([^\s]+):\\s*\\Z', line)
					if match:
						id = match.group(1)
						if id in self.conditions:
							raise PyMSError('Interpreter',"'%s' is already a condition name" % id,n,line)
						elif id in conditions:
							raise PyMSError('Interpreter',"'%s' is already a Condition Function name" % id,n,line)
						conditions[id] = []
						state = 8
						continue
					match = re.match('\\AActions ([^\s]+):\\s*\\Z', line)
					if match:
						id = match.group(1)
						if id in self.actions:
							raise PyMSError('Interpreter',"'%s' is already an action name" % id,n,line)
						elif id in self.actions:
							raise PyMSError('Interpreter',"'%s' is already an Action Function name" % id,n,line)
						actions[id] = []
						state = 9
						continue
					raise PyMSError('Interpreting','Invalid syntax, unknown line format',n,line)
		self.triggers = triggers
		self.strings = strings
		self.properties = properties

	def reference(self, file):
		file.write('#----------------------------------------------------\n# Parameter Types:\n')
		done = []
		for p in self.condition_parameters + self.action_parameters:
			if p:
				for t in p:
					if t:
						n = t.__doc__.split(' ',1)[0]
						if not n in done:
							file.write('#    %s\n' % t.__doc__)
							done.append(n)
		file.write('#\n# Conditions:\n')
		for c,ps in zip(self.conditions,self.condition_parameters):
			if c:
				file.write('#    %s(' % c)
				if ps:
					comma = False
					for p in ps:
						if comma:
							file.write(', ')
						else:
							comma = True
						file.write(p.__doc__.split(' ',1)[0])
				file.write(')\n')
		file.write('#\n# Actions:\n')
		for c,ps in zip(self.actions,self.action_parameters):
			file.write('#    %s(' % c)
			if ps:
				comma = False
				for p in ps:
					if comma:
						file.write(', ')
					else:
						comma = True
					file.write(p.__doc__.split(' ',1)[0])
			file.write(')\n')
		if self.ais[0][0] or self.ais[1][0]:
			file.write('#\n# AIScripts (Without Location):\n')
			for name,string in self.ais[0][0].iteritems():
				file.write('#    %s    |    %s\n' % (name, string))
			if self.ais[1][0]:
				file.write('#        -- BroodWar Only --\n')
				for name,string in self.ais[1][0].iteritems():
					file.write('#    %s    |    %s\n' % (name, string))
		if self.ais[0][1] or self.ais[1][1]:
			file.write('#\n# AIScripts (Requires a Location):\n')
			for name,string in self.ais[0][1].iteritems():
				file.write('#    %s    |    %s\n' % (name, string))
			if self.ais[1][1]:
				file.write('#        -- BroodWar Only --\n')
				for name,string in self.ais[1][1].iteritems():
					file.write('#    %s    |    %s\n' % (name, string))
		file.write('#----------------------------------------------------\n\n')

	def decompile(self, file, ref=False):
		try:
			f = open(file, 'w')
		except:
			raise PyMSError('Decompile',"Could not load file '%s'" % file)
		if ref:
			self.reference(f)
		for n,string in self.strings.iteritems():
			f.write('String %s:\n%s\n\n' % (n, TBL.decompile_string(string, '\x0A')))
		for n,property in self.properties.iteritems():
			f.write('Property %s:\n    ValidProperties(' % n)
			comma = False
			for n in range(16):
				if property[0] & (2 ** n):
					if comma:
						f.write(', ')
					else:
						comma = True
					f.write(unit_properties[n])
			f.write(')\n    ValidUnitData(')
			unitdata = ')\n'
			comma = False
			for n in range(7):
				if property[1] & (2 ** n):
					if comma:
						f.write(', ')
					else:
						comma = True
					f.write(unit_data[n])
					value = ''
					if n < 6:
						value = str(property[n + 2])
					if n in [1,2,3]:
						value += '%'
					unitdata += '    %s(%s)\n' % (unit_data[n], value)
			f.write(unitdata + '    Properties(')
			comma = False
			for n in range(16):
				if property[8] & (2 ** n):
					if comma:
						f.write(', ')
					else:
						comma = True
					f.write(unit_properties[n])
			f.write(')\n\n')
		for trigger in self.triggers:
			f.write('Trigger(')
			comma = False
			for n,player in enumerate(trigger[0]):
				if player:
					if comma:
						f.write(', ')
					else:
						comma = True
					f.write(player_ids[n])
			f.write('):\n    Conditions:\n')
			for condition in trigger[1]:
				enabled = ''
				if condition[7] & 2:
					enabled = '-'
				f.write('        %s%s(' % (enabled, self.conditions[condition[5]]))
				if self.condition_parameters[condition[5]]:
					comma = False
					for parameter in self.condition_parameters[condition[5]]:
						if comma:
							f.write(', ')
						else:
							comma = True
						f.write(str(parameter(True, condition)))
				f.write(')\n')
			f.write('    Actions:\n')
			for action in trigger[2]:
				enabled = ''
				if action[9] & 2:
					enabled = '-'
				f.write('        %s%s(' % (enabled, self.actions[action[7]]))
				if self.action_parameters[action[7]]:
					comma = False
					for parameter in self.action_parameters[action[7]]:
						if comma:
							f.write(', ')
						else:
							comma = True
						f.write(str(parameter(True, action, self.strings, self.properties)))
				f.write(')\n')
			f.write('\n')
		f.close()

	def compile(self, file, TRIG=False):
		try:
			f = open(file, 'wb')
		except:
			raise
		if not TRIG:
			f.write('qw\x986\x18\x00\x00\x00')
		props = []
		for trigger in self.triggers:
			writenext = []
			for condition in trigger[1]:
				f.write(struct.pack('<3LH4Bxx', *condition))
			f.write('\x00' * 20 * (16 - len(trigger[1])))
			for action in trigger[2]:
				if not TRIG:
					if action[1]:
						writenext.append([True,action[1]])
					if action[7] == 11 and action[5] not in props:
						props.append(action[5])
						action[9] ^= 8
						writenext.append([False,action[5]])
				elif (action[1] or action[7] == 11) and not action[9] & 2:
					action[9] ^= 2
				f.write(struct.pack('<6LH3B3x', *action))
			f.write('\x00' * 32 * (64 - len(trigger[2])))
			f.write(struct.pack('4x28B', *trigger[0]))
			for type,id in writenext:
				if type:
					f.write(self.strings[id] + '\x00' * (2048 - len(self.strings[id])))
				else:
					f.write(struct.pack('<HH4BLHH4x', *self.properties[id]))
		f.close()

#t = TRG()
#t.load_file('AG.trg')
#print t.triggers
#print t.strings
#print t.properties
#t.decompile('AG.txt')
#print condition_tunit(True, [0,0,0,37])
#print '-----'
#t.interpret('test.txt')
#t.compile('test.trg')
#t.load_file('test.trg')
#print t.triggers
#print t.strings
#print t.properties