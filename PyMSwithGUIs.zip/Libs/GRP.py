from utils import *

import struct

def frame_to_photo(p, g, f):
	image = [PhotoImage(width=g.width, height=g.height),-1,-1,-1,-1]
	for y,yd in enumerate(g.images[f]):
		if yd.count(0) != g.width:
			if image[3] == -1:
				image[3] = y
			image[4] = y + 1
			for x,xd in enumerate(yd):
				if xd:
					if image[1] == -1 or x < image[1]:
						image[1] = x
					if x >= image[2]:
						image[2] = x + 1
					image[0].put('#%02x%02x%02x' % tuple(p[xd]), (x,y))
	return image

class GRP:
	def __init__(self, palette=[[0,0,0]]*256):
		self.frames = 0
		self.width = 0
		self.height = 0
		self.palette = palette
		self.images = []

	def load_file(self, file, palette=None):
		try:
			f = open(file,'rb')
			data = f.read()
			f.close()
		except:
			raise PyMSError('Load',"Could not load the GRP '%s'" % file)
		try:
			frames, width, height = struct.unpack('<3H',data[:6])
			images = []
			for frame in range(frames):
				image = []
				xoffset, yoffset, linewidth, lines, framedata = struct.unpack('<4BL', data[6+8*frame:14+8*frame])
				image.extend([[0] * width for _ in range(yoffset)])
				for line in range(lines):
					linedata = []
					if xoffset > 0:
						linedata = [0] * xoffset
					offset = framedata+struct.unpack('<H',data[framedata+2*line:framedata+2+2*line])[0]
					#print '---- %s' % offset
					while len(linedata)-xoffset < linewidth:
						o = ord(data[offset])
						#print '%s - %s' % (hex(o),offset)
						if o >= 128:
							linedata.extend([0] * (o - 128))
							offset += 1
						elif o >= 64:
							linedata.extend([ord(data[offset+1])] * (o - 64))
							offset += 2
						else:
							linedata.extend([ord(c) for c in data[offset+1:offset+1+o]])
							offset += o + 1
					#raise
					# if len(linedata) - xoffset != linewidth:
						# raise
					image.append(linedata[:xoffset+linewidth] + [0] * (width-linewidth-xoffset))
				if len(image) < height:
					image.extend([[0] * width for _ in range(height - len(image))])
				images.append(image)
		except:
			#print linedata
			#raise
			raise PyMSError('Load',"Unsupported GRP file '%s', could possibly be corrupt or an uncompressed GRP" % file)
		self.frames = frames
		self.width = width
		self.height = height
		if palette:
			self.palette = list(palette)
		self.images = images

	def load_data(self, image, palette=None):
		self.frames = 1
		self.height = len(image)
		self.width = len(image[0])
		if palette:
			self.palette = list(palette)
		self.images = [list(image)]

	def save_file(self, file):
		try:
			f = open(file, 'wb')
		except:
			raise PyMSError('Save',"Could not save the GRP to '%s'" % file)
		f.write(struct.pack('<3H', self.frames, self.width, self.height))
		image_data = ''
		offset = 6 + 8 * self.frames
		frame_history = {}
		for z,frame in enumerate(self.images):
			x_min, x_max, y_min, y_max = (-1,)*4
			for y,line in enumerate(frame):
				if line != [0] * len(line):
					if y_min == -1:
						y_min = y
					y_max = y + 1
					for x,index in enumerate(line):
						if index:
							if x_min == -1 or x < x_min:
								x_min = x
							if x >= x_max:
								x_max = x + 1
			frame_hash = tuple(tuple(l[x_min:x_max]) for l in frame[y_min:y_max])
			if frame_hash in frame_history:
				f.write(frame_history[frame_hash])
			else:
				frame_data = struct.pack('<4BL', x_min, y_min, x_max - x_min, y_max - y_min, offset)
				frame_history[frame_hash] = frame_data
				f.write(frame_data)
				line_data = ''
				line_offset = 2 * (y_max - y_min)
				line_offsets = []
				line_history = {}
				for y,line in enumerate(frame[y_min:y_max]):
					line_hash = tuple(line)
					if line_hash in line_history:
						line_offsets.append(line_history[line_hash])
					else:
						data = ''
						last = line[x_min]
						if last:
							static = chr(last)
							repeat = 0
						else:
							static = ''
							repeat = 1
						for index in line[x_min+1:x_max]:
							if index == last:
								if repeat or not last:
									if last:
										if repeat < 63:
											if repeat < 2 and len(static) + repeat < 63:
												static += chr(index)
											elif repeat == 2 or len(static) + repeat >= 63:
												if repeat == 2 and len(static) > 2:
													data += chr(len(static)-2) + static[:-2]
												static = ''
											repeat += 1
										else:
											data += chr(127) + chr(index)
											static = chr(index)
											repeat = 1
									else:
										if repeat < 127:
											repeat += 1
										else:
											data += chr(255)
											repeat = 0
								else:
									static += chr(index)
									repeat = 2
							else:
								if repeat and (not last or repeat > 2 or len(static) == repeat):
									if last:
										data += chr(repeat+64) + chr(last)
									else:
										data += chr(repeat+128)
									if index:
										static = chr(index)
										repeat = 1
									else:
										static = ''
										repeat = 1
								elif index:
									if repeat:
										repeat = 0
									if len(static) < 63:
										static += chr(index)
									else:
										data += chr(63) + static[:63]
										if len(static) > 63:
											static = static[len(static)-63:] + chr(index)
										else:
											static = chr(index)
								else:
									if static:
										data += chr(len(static)) + static
									static = ''
									repeat = 1
							last = index
						if static:
							data += chr(len(static)) + static
						elif repeat:
							if last:
								data += chr(repeat+64) + chr(last)
							else:
								data += chr(repeat+128)
						line_data += data
						if line_offset > 65535:
							raise PyMSError('Save','The image has too much pixel data to compile')
						line_offsets.append(struct.pack('<H', line_offset))
						line_history[line_hash] = line_offsets[-1]
						line_offset += len(data)
				line_data = ''.join(line_offsets) + line_data
				image_data += line_data
				offset += len(line_data)
		f.write(image_data)
		f.close()

class UncompressedGRP(GRP):
	def __init__(self, palette=[[0,0,0]]*256):
		GRP.__init__(self, palette)

	def load_file(self, file, palette=None):
		try:
			f = open(file,'rb')
			data = f.read()
			f.close()
		except:
			raise PyMSError('Load',"Could not load the uncompressed GRP '%s'" % file)
		try:
			frames, width, height = struct.unpack('<3H',data[:6])
			images = []
			for frame in range(frames):
				image = []
				xoffset, yoffset, linewidth, lines, framedata = struct.unpack('<4BL', data[6+8*frame:14+8*frame])
				image.extend([[0] * width] * yoffset)
				for line in range(lines):
					linedata = []
					if xoffset > 0:
						linedata = [0] * xoffset
					linedata.extend(ord(index) for index in data[framedata:framedata+linewidth])
					image.append(linedata + [0] * (width-linewidth-xoffset))
					framedata += linewidth
				if len(image) < height:
					image.extend([[0] * width] * (height - len(image)))
				images.append(image)
		except:
			raise PyMSError('Load',"Unsupported uncompressed GRP file '%s', could possibly be corrupt or a compressed GRP" % file)
		self.frames = frames
		self.width = width
		self.height = height
		if palette:
			self.palette = list(palette)
		self.images = images

	def save_file(self, file):
		try:
			f = open(file, 'wb')
		except:
			raise PyMSError('Save',"Could not save uncompressed GRP to '%s'" % file)
		f.write(struct.pack('<3H', self.frames, self.width, self.height))
		image_data = ''
		offset = 6 + 8 * self.frames
		frame_history = {}
		for z,frame in enumerate(self.images):
			x_min, x_max, y_min, y_max = (-1,)*4
			for y,line in enumerate(frame):
				if line != [0] * len(line):
					if y_min == -1:
						y_min = y
					y_max = y + 1
					for x,index in enumerate(line):
						if index:
							if x_min == -1 or x < x_min:
								x_min = x
							if x >= x_max:
								x_max = x + 1
			data = ''.join(''.join(chr(i) for i in l[x_min:x_max]) for l in frame[y_min:y_max])
			if data in frame_history:
				f.write(frame_history[data])
			else:
				frame_data = struct.pack('<4BL', x_min, y_min, x_max - x_min, y_max - y_min, offset)
				f.write(frame_data)
				frame_history[data] = frame_data
				image_data += data
				offset += len(data)
		f.write(image_data)
		f.close()