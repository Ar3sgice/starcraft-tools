from Tkinter import *
from utils import *

import sys, traceback, webbrowser

class InternalErrorDialog(PyMSDialog):
	def __init__(self, parent, prog, handler):
		self.prog = prog
		self.handler = handler
		PyMSDialog.__init__(self, parent, 'PyMS Internal Error!', grabwait=False)

	def widgetize(self):
		self.bind('<Control-a>', self.selectall)
		self.resizable(False, False)
		Label(self, text='The PyMS program "%s" has encountered an unknown internal error.\nThe program will attempt to continue, but may crash once you press Ok.\nPlease contact poiuy_qwert and send him this traceback with any relivant information.' % self.prog, justify=LEFT).pack(side=TOP, padx=2, pady=2, fill=X)
		r = Frame(self)
		Hotlink(r, 'Contact', self.contact).pack(side=RIGHT, padx=10, pady=2)
		r.pack(fill=X)
		frame = Frame(self, bd=2, relief=SUNKEN)
		hscroll = Scrollbar(frame, orient=HORIZONTAL)
		vscroll = Scrollbar(frame)
		self.text = Text(frame, bd=0, highlightthickness=0, width=70, height=10, xscrollcommand=hscroll.set, yscrollcommand=vscroll.set, wrap=NONE, exportselection=0, state=DISABLED)
		self.text.grid(sticky=NSEW)
		hscroll.config(command=self.text.xview)
		hscroll.grid(sticky=EW)
		vscroll.config(command=self.text.yview)
		vscroll.grid(sticky=NS, row=0, column=1)
		frame.pack(fill=BOTH, pady=2, padx=2)
		buttonbar = Frame(self)
		ok = Button(buttonbar, text='Ok', width=10, command=self.ok)
		ok.pack(side=LEFT, padx=3)
		buttonbar.pack(side=BOTTOM, pady=10)
		return ok

	def selectall(self, key=None):
		self.text.focus_set()
		self.text.tag_add(SEL, 1.0, END)

	def ok(self):
		self.handler.window = None
		PyMSDialog.ok(self)

	def contact(self, e=None):
		webbrowser.open('file:///%s' % os.path.join(BASE_DIR, 'Docs', 'intro.html'))

class ErrorHandler:
	def __init__(self, toplevel, prog):
		self.toplevel = toplevel
		self.prog = prog
		self.window = None

	def write(self, text):
		if not self.window:
			self.window = InternalErrorDialog(self.toplevel, self.prog, self)
		self.window.text['state'] = NORMAL
		self.window.text.insert(END, text)
		self.window.text['state'] = DISABLED

def setup_trace(toplevel, prog):
	sys.stderr = ErrorHandler(toplevel, prog)