from Tkinter import *
from textwrap import wrap

import os,re

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
couriernew = ('Courier New', -12, 'normal')

def loadsize(window, settings, setting):
	set = settings[setting]
	window.geometry(set)
	window.update_idletasks()
	cur = window.winfo_geometry()
	if set != cur:
		def parsegeom(g):
			s = g.split('+',1)[0].split('x')
			return (int(s[0]),int(s[1]))
		sets = parsegeom(set)
		curs = parsegeom(cur)
		window.geometry('%sx%s+%s' % (sets[0] + (sets[0] - curs[0]),sets[1] + (sets[1] - curs[1]),cur.split('+',1)[1]))

def pprint(obj, depth=0):
	depth += 1
	string = ''
	if isinstance(obj, dict):
		if obj:
			string += '{\\\n'
			for key in obj:
				string += '%s%s:' % ('\t'*depth, repr(key))
				string += pprint(obj[key], depth)
			string += '%s},\\\n' % ('\t'*(depth-1))
		else:
			string += '{},\\\n'
	elif isinstance(obj, list):
		if obj:
			string += '[\\\n'
			for item in obj:
				string += ('%s' % ('\t'*depth))
				string += pprint(item, depth)
			string += '%s],\\\n' % ('\t'*(depth-1))
		else:
			string += '[],\\\n'
	else:
		string += '%s,\\\n' % (repr(obj),)
	if depth == 1:
		return string[:-3]
	return string

def ccopy(lst):
	r = []
	for item in lst:
		if isinstance(item, list):
			r.append(ccopy(item))
		else:
			r.append(item)
	return r

def fit(label, text, width=80, end=False):
	r = label
	s = len(r)
	indent = False
	for l in wrap(text, width - s):
		if indent:
			r += ' ' * s
		else:
			indent = True
		r += l
		if len(l) != width - s or end:
			r += '\n'
	return r

class PyMSError(Exception):
	def __init__(self, type, error, line=None, code=None, warnings=[]):
		self.type = type
		self.error = error
		self.line = line
		if self.line != None:
			self.line += 1
		self.code = code
		self.warnings = warnings

	def repr(self):
		r = '%s Error: %s' % (self.type, self.error)
		if self.line:
			r += '\n    Line %s: %s' % (self.line, self.code)
		return r

	def __repr__(self):
		r = fit('%s Error: ' % self.type, self.error)
		if self.line:
			r += fit('    Line %s: ' % self.line, self.code)
		if self.warnings:
			for w in self.warnings:
				r += repr(w)
		return r[:-1]

class PyMSWarning(Exception):
	def __init__(self, type, warning, line=None, code=None, extra=None, level=0):
		self.type = type
		self.warning = warning
		self.line = line
		if self.line != None:
			self.line += 1
		self.code = code
		self.extra = extra
		self.level = level

	def repr(self):
		r = fit('%s Warning: ' % self.type, self.warning, end=True)
		if self.line:
			r += fit('    Line %s: ' % self.line, self.code, end=True)
		return r

	def __repr__(self):
		r = fit('%s Warning: ' % self.type, self.warning)
		if self.line:
			r += fit('    Line %s: ' % self.line, self.code)
		return r[:-1]

class PyMSWarnList(Exception):
	def __init__(self, warnings):
		self.warnings = warnings

	def __repr__(self):
		r = ''
		for w in self.warnings:
			r += repr(w)
		return r[:-1]

class PyMSDialog(Toplevel):
	def __init__(self, parent, title, center=True, grabwait=True, hidden=False):
		Toplevel.__init__(self, parent)
		self.title(title)
		self.icon = parent.icon
		self.wm_iconbitmap(parent.icon)
		self.protocol('WM_DELETE_WINDOW', self.cancel)
		#self.transient(parent)
		self.parent = parent
		focus = self.widgetize()
		if not focus:
			focus = self
		focus.focus_set()
		self.update_idletasks()
		size = self.winfo_geometry().split('+',1)[0].split('x')
		if center:
			self.geometry('+%d+%d' % (self.winfo_screenwidth()/2-int(size[0])/2,self.winfo_screenheight()/2-int(size[1])/2))
		if grabwait:
			self.grab_set()
			self.wait_window(self)

	def widgetize(self):
		pass

	def ok(self):
		self.withdraw()
		self.update_idletasks()
		self.parent.focus_set()
		self.destroy()

	def cancel(self):
		self.ok()

class ErrorDialog(PyMSDialog):
	def __init__(self, parent, error):
		self.error = error
		PyMSDialog.__init__(self, parent, '%s Error!' % error.type)

	def widgetize(self):
		self.resizable(False, False)
		Label(self, justify=LEFT, anchor=W, text=self.error.repr(), wraplen=640).pack(pady=10, padx=5)
		frame = Frame(self)
		ok = Button(frame, text='Ok', width=10, command=self.ok)
		ok.pack(side=LEFT, padx=3)
		w = len(self.error.warnings)
		p = 1
		if w == 1:
			p = 0
		Button(frame, text='%s Warning%s' % (w, 's' * p), width=10, command=self.viewwarnings, state=[NORMAL,DISABLED][not self.error.warnings]).pack(side=LEFT, padx=3)
		Button(frame, text='Copy', width=10, command=self.copy).pack(side=LEFT, padx=6)
		frame.pack(pady=10)
		return ok

	def copy(self):
		self.clipboard_clear()
		self.clipboard_append(self.error.repr())

	def viewwarnings(self):
		WarningDialog(self, self.error.warnings)

class WarningDialog(PyMSDialog):
	def __init__(self, parent, warnings, cont=False):
		self.warnings = warnings
		self.cont = cont
		PyMSDialog.__init__(self, parent, 'Warning!')

	def widgetize(self):
		self.bind('<Control-a>', self.selectall)
		self.resizable(False, False)
		frame = Frame(self, bd=2, relief=SUNKEN)
		hscroll = Scrollbar(frame, orient=HORIZONTAL)
		vscroll = Scrollbar(frame)
		self.warntext = Text(frame, bd=0, highlightthickness=0, width=60, height=10, xscrollcommand=hscroll.set, yscrollcommand=vscroll.set, wrap=NONE, exportselection=0)
		self.warntext.tag_config('highlevel', foreground='#960000')
		self.warntext.grid()
		hscroll.config(command=self.warntext.xview)
		hscroll.grid(sticky=EW)
		vscroll.config(command=self.warntext.yview)
		vscroll.grid(sticky=NS, row=0, column=1)
		for warning in self.warnings:
			if warning.level:
				self.warntext.insert(END, warning.repr(), 'highlevel')
			else:
				self.warntext.insert(END, warning.repr())
		self.warntext['state'] = DISABLED
		frame.pack(side=TOP, pady=2, padx=2)
		buttonbar = Frame(self)
		ok = Button(buttonbar, text='Ok', width=10, command=self.ok)
		ok.pack(side=LEFT, padx=3)
		if self.cont:
			Button(buttonbar, text='Cancel', width=10, command=self.cancel).pack(side=LEFT)
		buttonbar.pack(pady=10)
		return ok

	def selectall(self, key=None):
		self.warntext.focus_set()
		self.warntext.tag_add(SEL, 1.0, END)

	def ok(self):
		self.cont = True
		PyMSDialog.ok(self)

	def cancel(self):
		self.cont = False
		PyMSDialog.ok(self)

class AboutDialog(PyMSDialog):
	def __init__(self, parent, program, version, thanks=None):
		self.program = program
		self.version = version
		self.thanks = thanks
		PyMSDialog.__init__(self, parent, 'About %s' % program)

	def widgetize(self):
		self.resizable(False, False)
		name = Label(self, text='%s %s' % (self.program, self.version), font=('', 18, 'normal'))
		name.pack()
		frame = Frame(self)
		Label(frame, text='Author:').grid(stick=E)
		Label(frame, text='Homepage:').grid(stick=E)
		Hotlink(frame, 'poiuy_qwert (p.q.poiuy_qwert@gmail.com)', self.author).grid(row=0, column=1, stick=W)
		Hotlink(frame, 'http://www.broodwarai.com/forums/index.php?showforum=40', self.homepage).grid(row=1, column=1, stick=W)
		frame.pack(padx=1, pady=2)
		if self.thanks:
			Label(self, text='Special Thanks To:', font=('', 10, 'bold')).pack(pady=2)
			thanks = Frame(self)
			font = ('', 8, 'bold')
			row = 0
			for who,why in self.thanks.iteritems():
				Label(thanks, text=who, font=font).grid(stick=E)
				Label(thanks, text=why).grid(row=row, column=1, stick=W)
				row += 1
			thanks.pack(pady=1)
		ok = Button(self, text='Ok', width=10, command=self.ok)
		ok.pack(pady=5)
		return ok

	def author(self, e=None):
		webbrowser.open('mailto:p.q.poiuy.qwert@hotmail.com')

	def homepage(self, e=None):
		webbrowser.open('http://www.broodwarai.com/forums/index.php?showforum=40')

	def broodwarai(self, e=None):
		webbrowser.open('http://www.broodwarai.com')

class Hotlink(Label):
	def __init__(self, parent, text, callback=None):
		Label.__init__(self, parent, text=text, foreground='#0000FF', cursor='hand2', font=('', 8, 'normal'))
		self.bind('<Enter>', self.enter)
		self.bind('<Leave>', self.leave)
		if callback:
			self.bind('<Button-1>', callback)

	def enter(self, e):
		self['font'] = ('', 8, 'underline')

	def leave(self, e):
		self['font'] = ('', 8, 'normal')

class Notebook(Frame):
	def __init__(self, parent, relief=RAISED, switchcallback=None):
		self.parent = parent
		self.active = None
		self.tab = IntVar()
		self.notebook = Frame(parent)
		self.tabs = Frame(self.notebook)
		self.tabs.pack(fill=X)
		self.pages = {}
		Frame.__init__(self, self.notebook, borderwidth=2, relief=relief)
		Frame.pack(self, fill=BOTH, expand=1)
		self.notebook.pack()

	def pack(self, **kw):
		self.notebook.pack(kw)

	def add_tab(self, fr, title):
		b = Radiobutton(self.tabs, text=title, indicatoron=0, variable=self.tab, value=len(self.pages), command=lambda: self.display(title))
		b.pack(side=LEFT)
		self.pages[title] = [fr,len(self.pages)]
		if not self.active:
			self.display(title)
		return b

	def display(self, title):
		if self.active:
			self.active.deactivate()
			self.active.forget()
		self.tab.set(self.pages[title][1])
		self.active = self.pages[title][0]
		self.active.pack(fill=BOTH, expand=1, padx=6, pady=6)
		self.active.activate()

class NotebookTab(Frame):
	def __init__(self, parent):
		self.parent = parent
		Frame.__init__(self, parent)

	def activate(self):
		pass

	def deactivate(self):
		pass

class DropDown(Frame):
	def __init__(self, parent, variable, entries, display=None, width=1, blank=None, state=NORMAL):
		self.variable = variable
		self.variable.set = self.set
		self.entries = entries
		self.display = display
		self.blank = blank
		if display and isinstance(display, Variable):
			display.callback = self.set
		self.size = min(10,len(entries))
		Frame.__init__(self, parent, borderwidth=2, relief=SUNKEN)
		self.listbox = Listbox(self, selectmode=SINGLE, font=couriernew, width=width, height=1, borderwidth=0)
		self.listbox.bind('<Button-1>', self.choose)
		bind = [
			('<MouseWheel>', self.scroll),
			('<Home>', lambda a,i=0: self.move(a,i)),
			('<End>', lambda a,i=END: self.move(a,i)),
			('<Up>', lambda a,i=-1: self.move(a,i)),
			('<Left>', lambda a,i=-1: self.move(a,i)),
			('<Down>', lambda a,i=1: self.move(a,i)),
			('<Right>', lambda a,i=-1: self.move(a,i)),
			('<Prior>', lambda a,i=-10: self.move(a,i)),
			('<Next>', lambda a,i=10: self.move(a,i)),
		]
		for b in bind:
			self.bind(*b)
		for entry in entries:
			self.listbox.insert(END, entry)
		self.listbox.insert(END, '')
		self.listbox.pack(side=LEFT, fill=X, expand=1)
		self.listbox['state'] = state
		arrow = PhotoImage(file=os.path.join(BASE_DIR, 'arrow.gif'))
		self.button = Button(self, image=arrow, command=self.choose, state=state)
		self.button.image = arrow
		self.button.pack(side=LEFT, fill=Y)

	def __setitem__(self, item, value):
		if item == 'state':
			self.listbox['state'] = value
			self.button['state'] = value
		else:
			Frame.__setitem__(self, item, value)

	def set(self, num):
		self.change(num)
		Variable.set(self.variable, num)

	def change(self, num):
		if num >= self.listbox.size():
			num = self.listbox.size()-1
		self.listbox.select_clear(0,END)
		self.listbox.select_set(num)
		self.listbox.see(num)

	def scroll(self, e):
		if self.listbox['state'] == NORMAL:
			if e.delta > 0:
				self.move(None, -1)
			elif self.blank != None or self.variable.get() < self.listbox.size()-2:
				self.move(None, 1)

	def move(self, e, a):
		if self.listbox['state'] == NORMAL:
			if a == END and self.blank != None:
				a = self.listbox.size()-2
			elif a not in [0,END]:
				a = max(min([self.listbox.size()-2,self.listbox.size()-1][self.blank == None],self.variable.get() + a),0)
			self.listbox.select_clear(0,END)
			self.listbox.select_set(a)
			self.listbox.see(a)
			self.disp(a)

	def choose(self, e=None):
		if self.listbox['state'] == NORMAL:
			i = self.variable.get()
			c = DropDownChooser(self, self.entries, i)
			self.variable.set(c.result)
			self.listbox.select_clear(0,END)
			self.listbox.select_set(c.result)
			self.listbox.see(c.result)
			self.disp(c.result)

	def disp(self, n):
		if self.display:
			if n == self.listbox.size()-1:
				n = self.blank
			if isinstance(self.display, Variable):
				self.display.set(n)
			else:
				self.display(n)

class TextDropDown(Frame):
	def __init__(self, parent, variable, history=[], width=None, state=NORMAL):
		self.variable = variable
		self.set = self.variable.set
		self.history = history
		Frame.__init__(self, parent, borderwidth=2, relief=SUNKEN)
		self.entry = Entry(self, textvariable=self.variable, width=width, bd=0)
		self.entry.pack(side=LEFT, fill=X, expand=1)
		self.entry['state'] = state
		arrow = PhotoImage(file=os.path.join(BASE_DIR, 'arrow.gif'))
		self.button = Button(self, image=arrow, command=self.choose, state=state)
		self.button.image = arrow
		self.button.pack(side=LEFT, fill=Y)

	def focus_set(self):
		self.entry.focus_set()

	def __setitem__(self, item, value):
		if item == 'state':
			self.entry['state'] = value
			self.button['state'] = value
		else:
			self.entry[item] = value

	def __getitem__(self, item):
		return self.entry[item]

	def choose(self, e=None):
		if self.entry['state'] == NORMAL and self.history:
			i = -1
			if self.variable.get() in self.history:
				i = self.history.index(self.variable.get())
			c = DropDownChooser(self, self.history, i)
			if c.result > -1:
				self.variable.set(self.history[c.result])

class DropDownChooser(Toplevel):
	def __init__(self, parent, list, select):
		self.focus = 0
		self.parent = parent
		self.result = select
		Toplevel.__init__(self, parent, relief=SOLID, borderwidth=1)
		self.protocol('WM_LOSE_FOCUS', self.select)
		self.wm_overrideredirect(1)
		scrollbar = Scrollbar(self)
		self.listbox = Listbox(self, selectmode=SINGLE, height=min(10,len(list)), borderwidth=0, font=couriernew, highlightthickness=0, yscrollcommand=scrollbar.set)
		for e in list:
			self.listbox.insert(END,e)
		if self.result > -1:
			self.listbox.select_set(self.result)
			self.listbox.see(self.result)
		self.listbox.bind('<ButtonRelease-1>', self.select)
		bind = [
			('<Enter>', lambda e,i=1: self.enter(e,i)),
			('<Leave>', lambda e,i=0: self.enter(e,i)),
			('<Button-1>', self.focusout),
			('<Return>', self.select),
			('<Escape>', self.close),
			('<MouseWheel>', self.scroll),
			('<Home>', lambda a,i=0: self.move(a,i)),
			('<End>', lambda a,i=END: self.move(a,i)),
			('<Up>', lambda a,i=-1: self.move(a,i)),
			('<Left>', lambda a,i=-1: self.move(a,i)),
			('<Down>', lambda a,i=1: self.move(a,i)),
			('<Right>', lambda a,i=-1: self.move(a,i)),
			('<Prior>', lambda a,i=-10: self.move(a,i)),
			('<Next>', lambda a,i=10: self.move(a,i)),
		]
		for b in bind:
			self.bind(*b)
		scrollbar.config(command=self.listbox.yview)
		if len(list) > 10:
			scrollbar.pack(side=RIGHT, fill=Y)
		self.listbox.pack(side=LEFT, fill=BOTH, expand=1)
		self.focus_set()
		self.update_idletasks()
		size = self.parent.winfo_geometry().split('+',1)[0].split('x')
		if self.parent.winfo_rooty() + self.parent.winfo_reqheight() + self.winfo_reqheight() > self.winfo_screenheight():
			self.geometry('%sx%s+%d+%d' % (size[0],self.winfo_reqheight(),self.parent.winfo_rootx(), self.parent.winfo_rooty() - self.winfo_reqheight()))
		else:
			self.geometry('%sx%s+%d+%d' % (size[0],self.winfo_reqheight(),self.parent.winfo_rootx(), self.parent.winfo_rooty() + self.parent.winfo_reqheight()))
		self.grab_set()
		self.update_idletasks()
		self.wait_window(self)

	def enter(self, e, f):
		self.focus = f

	def focusout(self, e):
		if not self.focus:
			self.select()

	def move(self, e, a):
		if not a in [0,END]:
			a = max(min(self.listbox.size()-1,int(self.listbox.curselection()[0]) + a),0)
		self.listbox.select_clear(0,END)
		self.listbox.select_set(a)
		self.listbox.see(a)

	def scroll(self, e):
		if e.delta > 0:
			self.listbox.yview('scroll', -2, 'units')
		else:
			self.listbox.yview('scroll', 2, 'units')

	def home(self, e):
		self.listbox.yview('moveto', 0.0)

	def end(self, e):
		self.listbox.yview('moveto', 1.0)

	def up(self, e):
		self.listbox.yview('scroll', -1, 'units')

	def down(self, e):
		self.listbox.yview('scroll', 1, 'units')

	def pageup(self, e):
		self.listbox.yview('scroll', -1, 'pages')

	def pagedown(self, e):
		self.listbox.yview('scroll', 1, 'pages')

	def select(self, e=None):
		s = self.listbox.curselection()
		if s:
			self.result = int(s[0])
		self.close()

	def close(self, e=None):
		self.withdraw()
		self.update_idletasks()
		self.destroy()
		self.parent.focus_set()

class CodeText(Frame):
	autoindent = re.compile('^([ \\t]*)')

	def __init__(self, parent, ecallback=None, icallback=None, scallback=None, acallback=None, state=NORMAL):
		self.edited = False
		# Edit Callback
		# INSERT Callback
		# Selection Callback
		# Auto-complete Callback
		self.ecallback = ecallback
		self.icallback = icallback
		self.scallback = scallback
		self.acallback = acallback

		Frame.__init__(self, parent, bd=2, relief=SUNKEN)
		frame = Frame(self)
		font = ('Courier New', -12, 'normal')
		self.lines = Text(frame, height=1, font=font, bd=0, bg='#E4E4E4', fg='#808080', width=8, cursor='')
		self.lines.pack(side=LEFT, fill=Y)
		hscroll = Scrollbar(self, orient=HORIZONTAL)
		self.vscroll = Scrollbar(self)
		self.text = Text(frame, height=1, font=font, bd=0, undo=1, maxundo=100, wrap=NONE, xscrollcommand=hscroll.set, yscrollcommand=self.yscroll, exportselection=0)
		self.text.pack(side=LEFT, fill=BOTH, expand=1)
		self.text.bind('<Control-a>', lambda e: self.after(1, self.selectall))
		self.text.bind('<Shift-Tab>', lambda e,i=True: self.indent(e, i))
		frame.grid(sticky=NSEW)
		hscroll.config(command=self.text.xview)
		hscroll.grid(sticky=EW)
		self.vscroll.config(command=self.yview)
		self.vscroll.grid(sticky=NS, row=0, column=1)
		self.grid_rowconfigure(0,weight=1)
		self.grid_columnconfigure(0,weight=1)

		self.lines.insert('1.0', '      1')
		self.lines.bind('<FocusIn>', self.selectline)
		self.text.mark_set('return', '1.0')
		self.text.orig = self.text._w + '_orig'
		self.tk.call('rename', self.text._w, self.text.orig)
		self.tk.createcommand(self.text._w, self.dispatch)

		self['state'] = state

		self.tag_configure = self.text.tag_configure
		self.tag_add = self.text.tag_add
		self.tag_remove = self.text.tag_remove
		self.tag_raise = self.text.tag_raise
		self.tag_nextrange = self.text.tag_nextrange
		self.tag_prevrange = self.text.tag_prevrange
		self.tag_ranges = self.text.tag_ranges
		self.tag_names = self.text.tag_names
		self.tag_bind = self.text.tag_bind
		self.tag_delete = self.text.tag_delete
		self.mark_set = self.text.mark_set
		self.index = self.text.index
		self.get = self.text.get
		self.see = self.text.see
		self.compare = self.text.compare
		self.edited = False
		self.afterid = None
		self.dodelete = None
		self.deleteid = None
		self.tags = {}
		# None - Nothing, True - Continue coloring, False - Stop coloring
		self.coloring = None

		self.setup()

	def focus_set(self):
		self.text.focus_set()

	def __setitem__(self, item, value):
		if item == 'state':
			self.lines['state'] = value
			self.text['state'] = value
		else:
			Frame.__setitem__(self, item, value)

	def selectall(self, e=None):
		self.text.tag_remove('Selection', '1.0', END)
		self.text.tag_add('Selection', '1.0', END)
		self.text.mark_set(INSERT, '1.0')

	def indent(self, e=None, dedent=False):
		item = self.text.tag_ranges('Selection')
		if item:
			if self.deleteid:
				self.after_cancel(self.deleteid)
				self.dodelete = None
				self.deleteid = None
			head,tail = self.index('%s linestart' % item[0]),self.index('%s linestart' % item[1])
			while self.text.compare(head, '!=', END) and self.text.compare(head, '<=', tail):
				if dedent and self.text.get(head) in ' \t':
					self.tk.call(self.text.orig, 'delete', head)
				elif not dedent:
					self.tk.call(self.text.orig, 'insert', head, '\t')
				head = self.index('%s +1line' % head)
			self.update_range(self.index('%s linestart' % item[0]), self.index('%s lineend' % item[1]))
			return True

	def yview(self, *args):
		self.lines.yview(*args)
		self.text.yview(*args)

	def yscroll(self, *args):
		self.vscroll.set(*args)
		self.lines.yview(MOVETO, args[0])

	def selectline(self, e=None):
		self.text.tag_remove('Selection', '1.0', END)
		head = self.lines.index('current linestart')
		tail = self.index('%s lineend+1c' % head)
		self.text.tag_add('Selection', head, tail)
		self.text.mark_set(INSERT, tail)
		self.text.focus_set()

	def setedit(self):
		self.edited = True

	def insert(self, index, text, tags=None):
		if text == '\t':
			if self.indent() or (self.acallback != None and self.acallback()):
				self.setedit()
				return
		self.setedit()
		if self.deleteid:
			try:
				self.tk.call(self.text.orig, 'delete', self.dodelete[0], self.dodelete[1])
			except:
				pass
			self.after_cancel(self.deleteid)
			self.dodelete = None
			self.deleteid = None
		if text == '\n':
			i = self.index('%s linestart' % index)
			while i != '1.0' and not self.get(i, '%s lineend' % i).split('#',1)[0]:
				i = self.index('%s -1lines' % i)
			m = self.autoindent.match(self.get(i, '%s lineend' % i))
			if m:
				text += m.group(1)
		i = self.text.index(index)
		self.tk.call(self.text.orig, 'insert', index, text, tags)
		self.update_lines()
		self.update_range(i, i + "+%dc" % len(text))

	def delete(self, start, end=None):
		self.setedit()
		try:
			self.tk.call(self.text.orig, 'delete', start, end)
		except:
			pass
		else:
			self.update_lines()
			self.update_range(start)

	def update_lines(self):
		lines = self.lines.get('1.0', END).count('\n')
		dif = self.text.get('1.0', END).count('\n') - lines
		if dif > 0:
			self.lines.insert(END, '\n' + '\n'.join(['%s%s' % (' ' * (7-len(str(n))), n) for n in range(lines+1,lines+1+dif)]))
		elif dif:
			self.lines.delete('%s%slines' % (END,dif),END)

	def update_range(self, start='1.0', end=END):
		self.tag_add("Update", start, end)
		if self.coloring:
			self.coloring = False
		if not self.afterid:
			self.afterid = self.after(1, self.docolor)

	def update_insert(self):
		if self.icallback != None:
			self.icallback()

	def update_selection(self):
		if self.scallback != None:
			self.scallback()

	def dispatch(self, cmd, *args):
		#print '%s %s' % (cmd, args)
		a = []
		if args:
			r = re.compile('\\bsel\\b')
			for n in args:
				if isinstance(n, str):
					a.append(r.sub('Selection', n))
		a = tuple(a)
		#print '%s %s' % (cmd, a)
		if cmd  == 'insert':
			self.after(1, self.update_insert)
			self.after(1, self.update_selection)
			return self.insert(*a)
		elif cmd == 'delete':
			self.dodelete = a
			self.deleteid = self.after(1, lambda n=a: self.delete(*n))
			self.after(1, self.update_insert)
			self.after(1, self.update_selection)
			return
		elif cmd == 'edit' and args[0] != 'separator':
			self.after(1, self.update_lines)
			self.after(1, self.update_range)
			self.after(1, self.update_insert)
			self.after(1, self.update_selection)
		elif cmd == 'mark' and args[0:2] == ('set', INSERT):
			self.after(1, self.update_insert)
		elif cmd == 'tag' and args[1] == 'Selection' and args[0] in ['set','remove']:
			self.after(1, self.update_selection)
		try:
			return self.tk.call((self.text.orig, cmd) + a)
		except TclError:
			return ""

	def setup(self, tags=None):
		r = self.tag_ranges('Selection')
		if self.tags:
			for tag in self.tags.keys():
				self.tag_delete(tag)
		if tags:
			self.tags = tags
		else:
			self.setupparser()
		self.tags['Update'] = {'foreground':None,'background':None,'font':None}
		if not 'Selection' in self.tags:
			self.tags['Selection'] = {'foreground':None,'background':'#C0C0C0','font':None}
		for tag, cnf in self.tags.items():
			if cnf:
				self.tag_configure(tag, **cnf)
		self.tag_raise('Selection')
		if r:
			self.tag_add('Selection', *r)
		self.text.focus_set()
		self.update_range()

	def docolor(self):
		self.afterid = None
		if self.coloring:
			return
		self.coloring = True
		self.colorize()
		self.coloring = None
		if self.tag_nextrange('Update', '1.0'):
			self.after_id = self.after(1, self.docolor)

	def setupparser(self):
		# Overload to setup your own parser
		pass

	def colorize(self):
		# Overload to do parsing
		pass

	def readlines(self):
		return self.text.get('1.0',END).split('\n')


class Tooltip:
	def __init__(self, widget, text='', font=None, delay=750, press=False, mouse=False):
		self.widget = widget
		self.setupbinds(press)
		self.text = text
		self.font = font
		self.delay = delay
		self.mouse = mouse
		self.id = None
		self.tip = None
		self.pos = None

	def setupbinds(self, press):
		self.widget.bind('<Enter>', self.enter, '+')
		self.widget.bind('<Leave>', self.leave, '+')
		self.widget.bind('<Motion>', self.motion, '+')
		self.widget.bind('<Button-1>', self.leave, '+')
		if press:
			self.widget.bind('<ButtonPress>', self.leave)

	def enter(self, e=None):
		self.unschedule()
		self.id = self.widget.after(self.delay, self.showtip)

	def leave(self, e=None):
		self.unschedule()
		self.hidetip()

	def motion(self, e=None):
		if self.id:
			self.widget.after_cancel(self.id)
			self.id = self.widget.after(self.delay, self.showtip)

	def unschedule(self):
		if self.id:
			self.widget.after_cancel(self.id)
			self.id = None

	def showtip(self):
		if self.tip:
			return
		self.tip = Toplevel(self.widget, relief=SOLID, borderwidth=1)
		self.tip.wm_overrideredirect(1)
		frame = Frame(self.tip, background='#FFFFC8', borderwidth=0)
		Label(frame, text=self.text, justify=LEFT, font=self.font, background='#FFFFC8', relief=FLAT).pack(padx=1, pady=1)
		frame.pack()
		pos = list(self.widget.winfo_pointerxy())
		self.tip.wm_geometry('+%d+%d' % (pos[0],pos[1]+22))
		self.tip.update_idletasks()
		move = False
		if not self.mouse:
			move = True
			pos = (self.widget.winfo_rootx() + self.widget.winfo_reqwidth(), self.widget.winfo_rooty() + self.widget.winfo_reqheight())
		if pos[0] + self.tip.winfo_reqwidth() > self.tip.winfo_screenwidth():
			move = True
			pos[0] = self.tip.winfo_screenwidth() - self.tip.winfo_reqwidth()
		if pos[1] + self.tip.winfo_reqheight() + 22 > self.tip.winfo_screenheight():
			move = True
			pos[1] -= self.tip.winfo_reqheight() + 44
		if move:
			self.tip.wm_geometry('+%d+%d' % (pos[0],pos[1]+22))

	def hidetip(self):
		if self.tip:
			self.tip.destroy()
			self.tip = None

class IntegerVar(StringVar):
	def __init__(self, val='0', range=[None,None], include=[], exclude=[], callback=None):
		StringVar.__init__(self)
		self.check = True
		self.defaultval = val
		self.lastvalid = val
		self.set(val)
		self.range = range
		self.include = include
		self.exclude = exclude
		self.callback = callback
		self.trace('w', self.editvalue)

	def editvalue(self, *_):
		if self.check:
			s = self.get(True)
			if s:
				try:
					if self.range[0] != None and self.range[0] >= 0 and self.get(True).startswith('-'):
						raise
					s = self.get()
					if not s in self.include and s in self.exclude:
						raise
				except:
					s = self.lastvalid
				else:
					if self.range[0] != None and s < self.range[0]:
						s = self.range[0]
					elif self.range[1] != None and s > self.range[1]:
						s = self.range[1]
				self.set(s)
				if self.callback:
					self.callback(s)
			elif self.range[0] != None:
				s = self.range[0]
			else:
				s = self.defaultval
			self.lastvalid = s
		else:
			self.lastvalid = self.get(True)
			self.check = True

	def get(self, s=False):
		if s:
			return StringVar.get(self)
		return int(StringVar.get(self))

class FloatVar(IntegerVar):
	def __init__(self, val='0', range=[None,None], include=[], exclude=[], callback=None, precision=None):
		self.precision = precision
		IntegerVar.__init__(self, val, range, include, exclude, callback)

	def editvalue(self, *_):
		if self.check:
			s = self.get(True)
			if s:
				try:
					if self.range[0] != None and self.range[0] >= 0 and self.get(True).startswith('-'):
						raise
					isfloat = self.get(True)
					s = self.get()
					if not s in self.include and s in self.exclude:
						raise
					s = str(s)
					if self.precision and not s.endswith('.0') and len(s)-s.index('.')-1 > self.precision:
						raise
					if not isfloat.endswith('.') and not isfloat.endswith('.0') and s.endswith('.0'):
						s = s[:-2]
						s = int(s)
					else:
						s = float(s)
				except:
					s = self.lastvalid
				else:
					if self.range[0] != None and s < self.range[0]:
						s = self.range[0]
					elif self.range[1] != None and s > self.range[1]:
						s = self.range[1]
				self.set(s)
				if self.callback:
					self.callback(s)
			elif self.range[0] != None:
				s = self.range[0]
			else:
				s = self.defaultval
			self.lastvalid = s
		else:
			self.lastvalid = self.get(True)
			self.check = True

	def get(self, s=False):
		if s:
			return StringVar.get(self)
		return float(StringVar.get(self))

class SStringVar(StringVar):
	def __init__(self, val='', length=0, callback=None):
		StringVar.__init__(self)
		self.check = True
		self.length = length
		self.lastvalid = val
		self.set(val)
		self.callback = callback
		self.trace('w', self.editvalue)

	def editvalue(self, *_):
		if self.check:
			s = self.get()
			if self.length and len(s) > self.length:
				self.set(self.lastvalid)
			else:
				self.lastvalid = s
				if self.callback:
					self.callback(s)
		else:
			self.lastvalid = self.get()
			self.check = True

class odict:
	def __init__(self, d=None):
		self.keynames = []
		self.dict = {}
		if d:
			self.keynames = list(d.keys)
			self.dict = dict(d.dict)

	def __delitem__(self, key):
		del self.dict[key]
		self.keynames.remove(key)

	def __setitem__(self, key, item):
		self.dict[key] = item
		if key not in self.keynames:
			self.keynames.append(key)

	def __getitem__(self, key):
		return self.dict[key]

	def __contains__(self, key):
		if key in self.keynames:
			return True
		return False

	def __len__(self):
		return len(self.keynames)

	def iteritems(self):
		iter = []
		for k in self.keynames:
			iter.append((k,self.dict[k]))
		return iter

	def iterkeys(self):
		return list(self.keynames)

	def peek(self):
		return (self.keynames[0],self.dict[self.keynames[0]])

	def keys(self):
		return list(self.keynames)

	def index(self, key):
		return self.keynames.index(key)

	def get(self, key, default=None):
		if not key in self.keynames:
			return default
		return self.dict[key]

	def getkey(self, n):
		return self.keynames[n]

	def getitem(self, n):
		return self.dict[self.keynames[n]]

	def remove(self, n):
		self.keynames.remove(n)
		del self.dict[n]

	def __repr__(self):
		return '%s@%s' % (self.keynames,self.dict)