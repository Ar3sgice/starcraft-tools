#####
Firegraft 0.93

Created by DiscipleOfAdun
#####

NOTE: This tool is intended for Window's PC's only.  This is due to the
      nature of the editing process, which uses Windows specific API
      calls and relies on the byte code present in the StarCraft executable
      file on said platform.

This version of Firegraft has full support for
	-1.15.1
	-1.15.0

This version of Firegraft has limited support for
	-1.14


About Firegraft:
	This program is a modification tool designed to allow access to
	the tech trees and button sets in StarCraft.  In addition, it
	also has support for editing several different aspects of the game
	normally un-editable.  This tool was created with modders in mind
	and was modeled after StarGraft and MemGraft, its predecessors.

	Firegraft uses a file with extension fgp to store all the data
	associated with a patch.  This file is placed inside MPQ archives
	and is loaded with a special patcher built into the executable files
	that are saved.  Firegraft also requires that a copy of your
	Starcraft executable be found so it can read the default settings
	for the requirements and buttons.  When first using Firegraft,
	you'll want to make a new file.  This loads up the default data
	from within the located exe.

	Open is used for 3 different things.  First, it is used to open 
	MPQ archives where current projects reside.  Secondly, it can be
	used to import .pat files that were created with StarGraft.  Third,
	it can be used to open the autosave files that are output by FG.

	Save has two formats.  The first is the archive save, which allows
	the files to be placed in an mpq archive.  The .scm and .scx 
	extensions are allowed because SCMLoader will support FG files from
	this release in the near future(at least, when SF updates it).  The
	second is the Executable save.  This is how you save when you want
	to test or distribute your changes.  The fgp file, along with 
	any selected plugins, both MPQDraft and Firegraft's own plugins,
	are saved out with a patcher which applies all the changes when ran.

	
#####
Features/restrictions that may not be apparent the first time around...

-Clicking on a button in the button preview sets it as the focused button.
-Double clicking on a blank spot in the button preview creates a blank button.
-The two -> buttons on the button sets tab jumps to the appropriate 
 requirement of the variable.
-Icons must be 32x32 and 256 colors.

#####
Frequently Asked Questions

Q: I only have two .exe edits.  What's wrong? 
A: You are probably on version 1.14 of StarCraft.  Upgrade to 1.15, and 
   everything will be fine.  The 1.14 file was left because of internal 
   testing purposes.

Q: I save my project as an MPQ, and run it in MPQDraft, but none of my changes
   are present.  Why? 
A: Firegraft patches are NOT meant to be ran in MPQDraft.  Save as an .exe
   instead of an .mpq file.

Q: When I run my exe patch, things go bad.  Why? 
A: This version of Firegraft has fixed those errors.

Q: How do I include my other files with a Firegraft patch? 
A: Put them in an MPQ and have it ready.  When you save as an .exe it will 
   ask you if you want to copy an archive into the saved file.  Select "yes", 
   find your mpq and select it.  All of your files will now be in the .exe.  
   If you need to update or change files, you can open the created .exe file 
   with WinMPQ to access the embedded mpq.

Q: Can Firegraft work on regular Battle.Net? 
A: Firegraft patches currently work on version 1.15 of StarCraft, and therefore 
   on regular Battle.Net.  However, when a new patch arrives, mods made with the 1.15 
   version will no longer be playable on regular Battle.net.

Q: Is there a Mac version? 
A: At this time, no, there is not. However, IanMM/Nai has put forward that he may 
   create one. No guarentees, though.  I also have another contact who has expressed
   interest in making a Mac patcher, but again, no guarentees.

Q: I don't understand anything about Firegraft. 
A: Firegraft is an advanced tool for fairly advanced Mod Makers.  It might help to 
   take a step back, and learn other basic forms of modding first.  Apart from that, 
   ask questions, find some good tutorials, and keep on trying.

Q: Where's the open option for MemGraft's mgp and mgd files?
A: It doesn't exist.  I'm still deciding if I should try to code it in.  Memgraft's 
   files are a bit different to open, and there were changes based on which version
   people had.  That makes a headache for me, along with a lot of possible places for
   things to go wrong.  If I have some free time and enough people request it, I'll
   consider adding it.

Q: Why don't all the presets set everything for all of them?  I tried making a spell
   but only the command settings were correct?  Is something wrong?

A: No, nothing is wrong.  This is the way the program works.  I have no clue where in
   your stat_txt.tbl and cmdicons file the correct strings and icons are, so it's up
   to you to put them in correctly.

#####
Bug reports, feedback, and other things can be sent to me the following ways

Post on any of the forums where I have an account or would see the post.  Prefered are
the STCF Firegraft forum, then Maplantis, Warboards, or Star Alliance.  However, I also
browse Campaign Creations and Blizzfourms, and will see anything there.  Also, a PM on 
any of those sites(except for CC, where I don't yet have an account) is another way to 
reach me.  I am also on IM quite often, see my profiles to get the contact info.  
Alternatively, you can email me at renegade_2395@yahoo.com with your questions and such.
